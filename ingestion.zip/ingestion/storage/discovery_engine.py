import hashlib
import json
import re
import warnings
from enum import Enum
from logging import Logger
from mimetypes import guess_type
from typing import List

from google.api_core.exceptions import NotFound, GoogleAPICallError
from google.api_core.client_options import ClientOptions
from google.cloud.discoveryengine_v1 import (
    CreateEngineRequest,
    DocumentServiceClient,
    Engine,
    EngineServiceClient,
    GcsSource,
    GetEngineRequest,
    ImportDocumentsRequest,
    SearchAddOn,
    SearchTier,
    SolutionType,
)
from google.cloud.storage import Blob

from ingestion.connectors.base_connector import Connector
from ingestion.models.storage import DataStoreDocument, DataStoreDocumentContent

warnings.filterwarnings(
    "ignore", message="The module `transfer_manager` is a preview feature"
)
warnings.filterwarnings(
    "ignore", message="Your application has authenticated using end user credentials"
)


class ImportType(Enum):
    DEFAULT = "default"
    LAYOUT_CHUNKING = "layout-chunking"
    LAYOUT = "layout"


def get_file_number(name: str, default=-1) -> int:
    """Get the file number if it exists in a file name.

    :param name: File name.
    :type name: str
    :param default: Default number of a file, defaults to -1
    :type default: int, optional
    :return: File number.
    :rtype: int
    """
    matches = re.findall(".*_(\d+).*", name)
    if len(matches) == 0:
        return default
    num = int(matches[0])
    return num


# Get list of pdf blobs
def blob_is_discovery_engine_compatible(blob: Blob, import_type: ImportType) -> bool:
    """Filter blobs that will fail loading into a data store.

    Reference: https://cloud.google.com/generative-ai-app-builder/docs/prepare-data#unstructured

    Args:
        blob: GCS Blob
        import_type: The type of processing that will be applied to the blob on import.
            'layout-chunking' is Layout parser with chunking.
            'layout' is Layout parser with no chunking.
    """
    blob_mime_type = guess_type(blob.name)[0]
    compatible = True
    if blob_mime_type not in DataStoreDocumentContent.get_allowed_mime_types():
        compatible = False
    else:
        check_size = None
        one_mb = 1024**2
        if blob_mime_type in [
            "text/html",
            "text/plain",
            "application/json",
            "application/xhtml+xml",
            "text/xml",
        ]:
            if import_type == ImportType.DEFAULT:
                check_size = 2.5 * one_mb
            else:
                check_size = 10 * one_mb
        elif blob_mime_type in [
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ]:
            check_size = 200 * one_mb
        elif blob_mime_type == "application/pdf":
            if import_type == ImportType.LAYOUT:
                check_size = 40 * one_mb
            else:
                check_size = 200 * one_mb
        if check_size is None:
            raise ValueError(f"mimetype {blob_mime_type} has no check_size")
        if blob.size >= check_size:
            compatible = False
    return compatible


def blob_to_metadata(blob: Blob) -> DataStoreDocument:
    properties: dict = blob.__dict__.get("_properties")
    json_data = properties.copy()
    del json_data["id"]
    del json_data["contentType"]
    document_id = properties.get("id", None)
    if document_id is None:
        raise ValueError("Blob id is None")
    blob_metadata = properties.get("metadata")
    if blob_metadata is None:
        raise ValueError("Blob metadata is None")
    return DataStoreDocument(
        id=hashlib.md5(document_id.encode()).hexdigest(),
        jsonData=json.dumps(blob_metadata),
        content=DataStoreDocumentContent(
            mimeType=guess_type(blob.name)[0],
            uri=f"gs://{properties.get('bucket')}/{properties.get('name')}",
        ),
    )

def import_from_connectors(
    connectors: list[Connector],
    project: str,
    location: str,
    data_store_id: str,
    logger: Logger,
) -> None:
    logger.info(f"Starting bulk import for data store: {data_store_id}")
    
    document_service_client = DocumentServiceClient(
        client_options=ClientOptions(api_endpoint=f"{location}-discoveryengine.googleapis.com")
    )
    
    # iterating through connector specific data_store_metadata_blobs to compute and store their URIs in one list
    input_uris = []
    for connector in connectors:
        connector.get_or_create_data_store(logger=logger, project=project, location=location)
        data_store_documents = connector.get_data_store_documents()

        if not data_store_documents:
            logger.info("No documents found to prepare for import.")
            continue

        data_store_metadata_blob = connector.get_or_create_data_store_metadata_blob()
        
        logger.info(f"Writing {len(data_store_documents)} document metadata records to {data_store_metadata_blob.name}")
        with data_store_metadata_blob.open("w") as f:
            for document in data_store_documents:
                f.write(document.model_dump_json() + "\n")

        uri = f"gs://{connector.gcs_storage_config.bucket_name}/{data_store_metadata_blob.name}"
        input_uris.append(uri)

    parent = document_service_client.branch_path(
        project=project,
        location=location,
        data_store=data_store_id,
        branch="default_branch",
    )
    
    import_request = ImportDocumentsRequest(
        gcs_source=GcsSource(input_uris=input_uris),
        reconciliation_mode=ImportDocumentsRequest.ReconciliationMode.FULL,
        parent=parent,
    )
    
    logger.info(f"Updating data store with {len(input_uris)} sources...")
    logger.debug(f"Sources: {input_uris}")

    import_operation = document_service_client.import_documents(request=import_request)
    
    try:
        # Block for an hour or until complete
        import_operation_response = import_operation.result(timeout=3600)
        logger.info("Import operation completed successfully.")
        logger.info(import_operation_response)
    except GoogleAPICallError as e:
        logger.exception("A failure occurred during the import operation.")
        raise e

    logger.info("Done")
    
    
def get_or_create_engine(
    project: str, engine_id: str, data_store_ids: List[str], logger: Logger
):
    # Create engine
    engine_service_client = EngineServiceClient()
    try:
        # Engine already exists
        logger.info("Checking if engine exists...")
        get_engine_request = GetEngineRequest(
            name=engine_service_client.engine_path(
                project=project,
                location="global",
                collection="default_collection",
                engine=engine_id,
            )
        )
        engine = engine_service_client.get_engine(get_engine_request)
    except NotFound:
        logger.info("Engine doesn't exist, creating...")
        create_engine_request = CreateEngineRequest(
            parent=engine_service_client.collection_path(
                project=project,
                location="global",
                collection="default_collection",
            ),
            engine=Engine(
                search_engine_config=Engine.SearchEngineConfig(
                    search_tier=SearchTier.SEARCH_TIER_ENTERPRISE,
                    search_add_ons=[SearchAddOn.SEARCH_ADD_ON_LLM],
                ),  # Adds LLM
                name=engine_service_client.engine_path(
                    project=project,
                    location="global",
                    collection="default_collection",
                    engine=engine_id,
                ),
                display_name=engine_id,
                data_store_ids=data_store_ids,
                solution_type=SolutionType(2),  # Search
            ),
            engine_id=engine_id,
        )
        create_operation = engine_service_client.create_engine(create_engine_request)
        engine = create_operation.result()
        logger.info(engine)
    logger.info("Done")


def create_or_update_datastore(
    project: str, domain: str, connectors: list[Connector], logger: Logger
) -> None:
    get_or_create_engine(
        project=project,
        engine_id=domain + "-engine",
        data_store_ids=[connector.get_data_store_id() for connector in connectors],
        logger=logger,
    )
