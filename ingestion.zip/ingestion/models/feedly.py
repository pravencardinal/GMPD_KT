from typing import List, Optional
from pydantic import BaseModel, Field
from sqlalchemy import Engine
from sqlmodel import Field, SQLModel, select, Session, or_, text
import pandas as pd

class FeedlyStreamDetails(BaseModel):
    stream_id: str
    json_query: dict


class FeedlyStream(BaseModel):
    name: str
    details: FeedlyStreamDetails

class SalesCoPilotNewMedication(BaseModel):
    medication_name: str = Field(description="Name of the upcoming medication")
    medication_categorization: str = Field(description="Which of the following 3 categories does the medication fall under? Cell & Gene, Small Molecule, or Biologics. If there is not enough information to decide between one of these categories please put 'N/A'")

    medication_disease: str = Field(description="The disease that the medication is targeting")
    filing_window: str = Field(description="Expected launch window for the medication to enter IND, NDA, or to be sent to the FDA")
    filing_type: str = Field(description="Filing type, NDA/IND/BLA")
    
    def to_dict(self):
        return {
            'medication_name': self.medication_name,
            'filing_window': self.launch_window
        }

class SalesCoPilotEntry(BaseModel):
    companies: List[str] = Field(description="List of companies intending to bring new drugs to market.")
    medications: List[SalesCoPilotNewMedication] = Field(description="List of medications that are being developed and have yet to reach the FDA.")
    
    def to_dict(self):
        return {
            'companies': self.companies,
            'medications': [m.to_dict for m in self.medications]
        }
    
class SalesCoPilotEntryWithMetaData():    
    def __init__(self, entry: SalesCoPilotEntry, metadata: dict):
        self.entry = entry
        self.metadata = metadata
        
    def to_dict(self):
        return {
            'entry': self.entry.to_dict(),
            'metadata': self.metadata
        }
        
# If structured output support is ever added to google search grounded calls then use this
class SalesCopilotContact(BaseModel):
    contact_name: str
    job_title: str
    co_founder_ceo: str
    email: str
    phone_number: str
    website: str
        
class SalesCopilotContactInfo(BaseModel):
    approval_status: str
    approval_information: str
    location: str
    contacts_list: List[dict]

class Excluded_Companies(SQLModel, table=True):
    __table_name__ = "excluded_companies"
    pk: Optional[int] = Field(primary_key=True)
    companies: str = Field(nullable=False, unique=True)
    
class Parameters(SQLModel, table=True):
    __table_name__ = "parameters"
    pk: Optional[int] = Field(primary_key=True)
    name: str = Field(nullable=False, unique=True)
    value: str = Field(nullable=False, unique=True)
    
class Email_Recipients(SQLModel, table=True):
    __tablename__ = "email_recipients"
    pk: Optional[int] = Field(primary_key=True)
    email: str = Field(nullable=False, unique=True)
    
class States_and_Analysts(SQLModel, table=True):
    __tablename__ = "states_and_analysts"
    pk: Optional[int] = Field(primary_key=True)
    state: str = Field(nullable=False, unique=True)
    state_shorthand: str = Field(nullable=False, unique=True)
    analyst: str = Field(nullable=False, unique=True)
    
class Queries:
    
    # I was unable to get this to work with the select() function, I think something was wrong with how I was structuring the query using the ORM but I could not for the life of me figure it out
    def data_for_augmenting(engine: Engine) -> pd.DataFrame:
        query = """
        SELECT * FROM initial_extracted_data 
        where job_timestamp IN 
            (SELECT MAX(job_timestamp)FROM initial_extracted_data)
        AND (filing_window = 'N/A' OR TO_DATE_CUSTOM(filing_window, 'YYYY/MM/DD', 'MM/DD/YYYY') > CURRENT_DATE);
        """
        
        with engine.connect() as conn:
            return pd.read_sql_query(sql=query, con=conn.connection)
    
    def create_date_function(session: Session):
        query = """
        CREATE OR REPLACE FUNCTION to_date_custom(ADate TEXT, AFormat TEXT, ASecondFormat TEXT) RETURNS DATE AS $$
        BEGIN
            RETURN to_date(ADate, AFormat);
        EXCEPTION
            WHEN others THEN
                BEGIN
                    RETURN to_date(ADate, ASecondFormat);
                EXCEPTION
                    WHEN others THEN
                        RETURN NULL;
                END;
                RETURN NULL;
        END;
        $$ LANGUAGE plpgsql IMMUTABLE STRICT;"""
        session.exec(text(query))
        
    def get_excluded_companies(session: Session) -> List[str]:
        return session.query(Excluded_Companies.companies).all()
    
    def get_emails(session: Session) -> List[str]:
        return session.query(Email_Recipients.email).all()
        
    def get_param(session: Session, param: str) -> str:
        select_statement = select(Parameters.value).where((Parameters.name == param))
        return session.exec(select_statement).first()
    
    def get_analyst(session: Session, state: str) -> str:
        statement = select(States_and_Analysts.analyst).where(or_(States_and_Analysts.state == state, States_and_Analysts.state_shorthand == state))
        return session.exec(statement).first()