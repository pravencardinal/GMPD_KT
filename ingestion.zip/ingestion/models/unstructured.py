from typing import Any, List, Optional

from pydantic import BaseModel, field_validator
from unstructured.documents.elements import (
    TYPE_TO_TEXT_ELEMENT_MAP,
    Element,
    ElementMetadata,
)


class UnstructuredElement(BaseModel):
    """A wrapper class around the Element class in unstructured."""

    id: Optional[str] = None
    type: str
    text: str
    metadata: dict

    def to_element(self) -> Element:
        metadata = ElementMetadata(**self.metadata)
        element: Element = TYPE_TO_TEXT_ELEMENT_MAP.get(self.type)(
            text=self.text, metadata=metadata, element_id=self.id
        )
        return element


class DocumentElements(BaseModel):
    """This is a class that holds the results of a partition_X call for a single document.
    :param elements: A single document's unstructured Element's list.
    """

    elements: List[UnstructuredElement]
    # Document level metadata
    metadata: Optional[dict] = {}

    def __len__(self) -> int:
        return len(self.elements)

    @field_validator("metadata")
    @classmethod
    def replace_none(cls, v: Any, values: dict, **kwargs) -> dict:
        if v is None:
            return {}
        return v

    @classmethod
    def from_element_list(
        cls,
        element_list: List[Element],
        metadata: dict = {},
    ) -> "DocumentElements":
        """Helper function to convert a list of unstructured Elements to DocumentElements.

        :param element_list: List of unstructured Elements.
        :type element_list: List[Element]
        :param name: Document name.
        :type name: str
        :param metadata: Document metadata, defaults to {}
        :type metadata: dict, optional
        :param id: Document UUID, defaults to None
        :type id: UUID, optional
        :return: DocumentElements object.
        :rtype: DocumentElements
        """
        document_elements = DocumentElements(elements=[], metadata=metadata)
        for element in element_list:
            unstructured_element = UnstructuredElement(**element.to_dict())
            document_elements.elements.append(unstructured_element)
        return document_elements

    def to_element_list(self) -> List[Element]:
        return [element.to_element() for element in self.elements]
