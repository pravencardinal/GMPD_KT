from datetime import date, datetime

from pydantic.v1 import BaseModel


class Record(BaseModel):
    """A pydantic model representing the aspects of a ServiceNow API record object that we need."""

    sys_id: str
    parent: str
    number: str
    sys_created_on: datetime
    sys_created_by: str
    sys_updated_by: str
    text: str
    author: str
    active: bool
    published: date
    version: str
    kb_knowledge_base: str
    topic: str
    article_id: str
