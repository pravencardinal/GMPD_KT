from pathlib import Path

from google.cloud.exceptions import NotFound
from google.cloud.storage import Bucket
from pydantic import BaseModel, field_validator


class EdgarFile(BaseModel):
    cik: str | int
    form: str
    accession_number: str
    prefix: str = "edgar/data/"

    @field_validator("cik")
    @classmethod
    def validate_cik(cls, v: str | int) -> str:
        if isinstance(v, int):
            return str(v).zfill(10)
        elif isinstance(v, str):
            return v
        else:
            raise ValueError(f"cik must be str or int, not {type(v)}")

    def __str__(self):
        return f"CIK: {self.cik.zfill(10)} | Form: {self.form} | Accession: {self.accession_number}"

    def get_edgar_path(self) -> str:
        return self.prefix + f"/{int(self.cik)}/{self.accession_number}.txt"

    def get_gcs_path(self, prefix: str) -> Path:
        download_path = f"{prefix}/{self.cik}/{self.form}/{self.accession_number}.txt"
        return download_path

    def exists(self, prefix: str, bucket: Bucket) -> bool:
        try:
            bucket.get_blob(self.get_gcs_path(prefix))
            return True
        except NotFound:
            return False
