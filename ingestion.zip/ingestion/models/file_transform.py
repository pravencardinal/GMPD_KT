from typing import List

from pydantic import BaseModel, Field


class StructuredTranscriptItem(BaseModel):
    """A single segment of the transcript with speaker and timestamp."""

    speaker_label: str = Field(
        description="The label for the speaker (e.g., 'Speaker 1'). Include names if known."
    )
    timestamp: str = Field(
        description="The timestamp of the utterance in HH:MM:SS (Hour:Minute:Second) format."
    )
    text: str = Field(description="The transcribed text for this segment.")


class Transcription(BaseModel):
    """The root JSON object for the entire transcription and analysis."""

    structured_transcript: List[StructuredTranscriptItem]
