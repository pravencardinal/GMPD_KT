from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel

DEFAULT_SEP = "|||"


class SalesforceDocument(BaseModel):
    id: str
    content_modified_date: datetime
    title: str

    @classmethod
    def from_uri(
        cls, prefix: str, uri: str, sep: str = DEFAULT_SEP
    ) -> "SalesforceDocument":
        uri = uri.replace(prefix, "")
        _, _, components = uri.split("/", 2)
        document_id, datetime_str, title = components.split(sep)
        return SalesforceDocument(
            id=document_id, content_modified_date=datetime_str, title=title
        )

    def to_uri(self, prefix: str, agreement_id: str, sep: str = DEFAULT_SEP) -> str:
        return f"{prefix}/{agreement_id}/" + sep.join(
            [self.id, self.content_modified_date.isoformat(), self.title]
        )

    def __hash__(self) -> int:
        return hash((self.id, self.content_modified_date.isoformat(), self.title))


class Agreement(BaseModel):
    agreement_id: str
    salesforce_documents: Optional[List[SalesforceDocument]] = None
    metadata: dict[str, str | None] = {}
