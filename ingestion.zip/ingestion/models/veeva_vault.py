from datetime import datetime
from mimetypes import guess_type

from google.cloud.storage import Blob, Bucket

from ingestion.models.domain_explorer_blob import DomainExplorerBlobMetadata


class VeevaVaultFile(DomainExplorerBlobMetadata):
    document_number: str

    @classmethod
    def from_blob(cls, blob: Blob) -> "VeevaVaultFile":
        blob_metadata = blob.metadata
        if blob_metadata is None:
            blob_metadata = {}
        return VeevaVaultFile(
            source_id=blob_metadata.get("source_id"),
            name=blob_metadata.get("name"),
            last_updated=blob_metadata.get(
                "last_updated", datetime(year=1, month=1, day=1)
            ),
            content_type=blob_metadata.get("content_type", guess_type(blob.name)[0]),
            path=blob_metadata.get("path"),
            connector_type=blob_metadata.get("connector_type"),
            document_number=blob_metadata.get("document_number"),
            link=blob_metadata.get("link"),
        )

    def to_blob(self, docs_path: str, bucket: Bucket) -> Blob:
        return bucket.get_blob()

    def __hash__(self) -> int:
        return hash(
            (
                self.source_id,
                self.name,
                self.last_updated,
                self.content_type,
                self.path,
                self.connector_type,
                self.document_number,
                self.link,
            )
        )
