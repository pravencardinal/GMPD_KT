from typing import Any, Optional

from google.api_core.exceptions import NotFound
from google.cloud.secretmanager_v1 import (
    AccessSecretVersionRequest,
    SecretManagerServiceClient,
)
from pydantic import BaseModel, Field, model_validator
from typing_extensions import Self


class SecretConfigModel(BaseModel):
    project: str

    @model_validator(mode="before")
    def get_secrets(cls, data: Any) -> Self:
        secret_client = SecretManagerServiceClient()
        missing_secrets = []
        for field_name, field_info in cls.model_fields.items():
            if field_info.json_schema_extra is None:
                continue
            if field_info.json_schema_extra.get("secret", False):
                secret_name = field_info.json_schema_extra.get("secret_name", None)
                if secret_name is None:
                    raise NotFound(f"Secret {field_name} not found")
                try:
                    access_response = secret_client.access_secret_version(
                        request=AccessSecretVersionRequest(
                            name=secret_client.secret_version_path(
                                project=data.get("project", None),
                                secret=secret_name,
                                secret_version="latest",
                            )
                        )
                    )
                    field_value = access_response.payload.data.decode("utf-8")
                    data[field_name] = field_value
                except NotFound:
                    missing_secrets.append(secret_name)
        if len(missing_secrets) > 0:
            raise ValueError(
                "secrets not in Secret Manager: " + ",".join(missing_secrets)
            )
        return data


class GCSStorageConfig(SecretConfigModel):
    bucket_name: str = Field(
        default=None, secret=True, secret_name="ingestion-bucket-name"
    )


class Peopledatalabs(SecretConfigModel):
    api_key: str = Field(
        default=None, secret=True, secret_name="ingestion-peopledatalabs-api-key"
    )


class ChunkingConfig(BaseModel):
    """The unstructured chunking kwargs used for chunking."""

    multipage_sections: bool = True
    combine_text_under_n_chars: Optional[int] = 512
    new_after_n_chars: Optional[int] = 1024
    max_characters: int = 1280  # This could None
    overlap: int = 64
    overlap_all: bool = False


class ServiceNowAPIConfig(SecretConfigModel):
    """Required information to authenticate with the ServiceNow API."""

    client_id: str = Field(
        default=None, secret=True, secret_name="ingestion-service-now-api-client-id"
    )
    client_secret: str = Field(
        defaut=None, secret=True, secret_name="ingestion-service-now-api-client-secret"
    )
    username: str = Field(
        default=None, secret=True, secret_name="ingestion-service-now-api-username"
    )
    password: str = Field(
        default=None, secret=True, secret_name="ingestion-service-now-api-password"
    )


class GCPConfig(SecretConfigModel):
    """GCP project config.

    bucket (str): The bucket where data is stored.
    consumer_project_id (str): The ID of the project that routes LLM calls to the producer.
    provider_project_id (str): The ID of the project that provides access to LLMs.
    region (str): The region we utilize.
    """

    provider_project_id: str = Field(
        default=None, secret=True, secret_name="ingestion-provider-project-id"
    )


class DatabaseConfig(SecretConfigModel):
    """
    Defines arguments required to connect to postgres.

    user (str): The username. Defaults to None.
    password (str): The password. Defaults to None.
    host (str): The host. Defaults to None.
    port (int): The port. Defaults to None.
    """

    username: str = Field(default=None, secret=True, secret_name="database-user")
    password: str = Field(default=None, secret=True, secret_name="database-password")
    host: str = Field(default=None, secret=True, secret_name="database-host")
    port: int = Field(default=None, secret=True, secret_name="ingestion-database-port")


class ConfluenceConfig(SecretConfigModel):
    access_token: str = Field(
        default=None, secret=True, secret_name="ingestion-confluence-access-token"
    )


class SalesforceConfig(SecretConfigModel):
    username: str = Field(
        default=None, secret=True, secret_name="ingestion-salesforce-username"
    )
    client_id: str = Field(
        default=None, secret=True, secret_name="ingestion-salesforce-client-id"
    )
    client_secret: str = Field(
        default=None, secret=True, secret_name="ingestion-salesforce-client-secret"
    )
    password: str = Field(
        default=None, secret=True, secret_name="ingestion-salesforce-client-password"
    )


class MicrosoftGraphConfig(SecretConfigModel):
    client_id: str = Field(default=None, secret=True, secret_name="entra-client-id")
    username: str = Field(
        default=None, secret=True, secret_name="service-account-username"
    )
    password: str = Field(
        default=None, secret=True, secret_name="service-account-password"
    )
    scopes: list[str] = ["https://graph.microsoft.com/.default"]


class VeevaVaultConfig(SecretConfigModel):
    client_id: str = Field(
        default=None, secret=True, secret_name="ingestion-veeva-vault-client-id"
    )
    username: str = Field(
        default=None, secret=True, secret_name="ingestion-veeva-vault-username"
    )
    password: str = Field(
        default=None, secret=True, secret_name="ingestion-veeva-vault-password"
    )
    vaultDNS: str = Field(
        default=None, secret=True, secret_name="ingestion-veeva-vault-DNS"
    )
    oauth_oidc_profile_id: str = Field(
        default=None, secret=True, secret_name="ingestion-veeva-vault-oidc-profile-id"
    )

    identity_auth_url: str = Field(
        default=None, secret=True, secret_name="ingestion-identity-auth-url"
    )


class FeedlyConfig(SecretConfigModel):
    access_token: str = Field(
        default=None, secret=True, secret_name="ingestion-feedly-access-token"
    )

    smtp_address: str = Field(
        default=None, secret=True, secret_name="ingestion-feedly-smtp-address"
    )

    llm_model: str = Field(
        default=None, secret=True, secret_name="ingestion-feedly-llm-model"
    )

    feed_name: str = Field(
        default=None, secret=True, secret_name="ingestion-feedly-feed-name"
    )
