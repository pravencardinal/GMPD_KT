import json
from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, Field
from typing_extensions import Annotated

from ingestion.models.domain_explorer_blob import DomainExplorerBlobMetadata

SCHEMA_NAME = "confluence"


class ConfluenceSpace(BaseModel):
    key: str
    ignore_paths: List[str] = []


class ExportView(BaseModel):
    value: str
    representation: str


class ConfluenceDocumentBody(BaseModel):
    export_view: ExportView


class ConfluenceDocumentVersion(BaseModel):
    when: datetime
    number: int


class ConfluenceDocument(DomainExplorerBlobMetadata):
    """Pydantic model to encapsulate the information for a Confluence document."""

    version_number: Optional[int] = None
    type: str  # ex: page or attachment
    status: str  # ex: draft or current
    space: Optional[ConfluenceSpace] = None
    ancestors: Optional[List["ConfluenceDocument"]] = None
    links: Annotated[
        Dict[str, str],
        Field(alias="_links"),
    ]  # These are links we use to download later
    body: Optional[ConfluenceDocumentBody] = None  # Page content

    def __hash__(self) -> int:
        return int(self.source_id)

    def get_url(self, host: str, link_type: str = "webui") -> str:
        path = self.links.get(link_type, None)
        if path is None:
            raise ValueError(
                f"{link_type} link is None for data: {json.dumps(self.links)}"
            )
        return host + path

    def __repr__(self) -> str:
        return (
            f"[ConfluenceDocument | id={self.source_id} | type={self.type} "
            + f"| title={self.name}]"
        )
