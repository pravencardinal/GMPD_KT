import re
from typing import Any, Literal, get_args

from pydantic import BaseModel, field_validator


class DataStoreDocumentContent(BaseModel):
    mimeType: Literal[
        "application/json",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/xhtml+xml",
        "text/html",
        "text/plain",
        "text/xml",
    ]
    uri: str

    @classmethod
    def get_allowed_mime_types(cls) -> tuple[str]:
        return get_args(cls.model_fields["mimeType"].annotation)


class DataStoreDocument(BaseModel):
    id: str
    jsonData: str
    content: DataStoreDocumentContent

    @field_validator("id")
    @classmethod
    def validate_field(cls, v: Any) -> str:
        if not isinstance(v, str):
            v = str(v)
        if len(v) > 63:
            raise ValueError(f"id value {v} cannot be longer than 63 characters")
        if not re.match("[a-zA-Z0-9][a-zA-Z0-9-_]*", v):
            raise ValueError(
                f"document.id value {v} did not match pattern [a-zA-Z0-9][a-zA-Z0-9-_]*"
            )
        return v
