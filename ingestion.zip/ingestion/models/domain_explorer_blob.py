from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class DomainExplorerBlobMetadata(BaseModel):
    source_id: str
    name: str
    path: str
    connector_type: str
    last_updated: datetime
    content_type: Optional[str] = None
    link: Optional[str] = None
    duration: Optional[int] = None
