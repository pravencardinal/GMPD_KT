from datetime import datetime
from typing import Union

from google.cloud.storage import Blob, Bucket
from msgraph.generated.models.site import Site
from pydantic import BaseModel

from ingestion.models.domain_explorer_blob import DomainExplorerBlobMetadata


class SharepointFile(DomainExplorerBlobMetadata):
    size: int

    @classmethod
    def from_blob(cls, blob: Blob) -> "SharepointFile":
        blob_metadata = blob.metadata
        if blob_metadata is None:
            blob_metadata = {}
        return SharepointFile(
            source_id=blob_metadata.get("source_id"),
            name=blob_metadata.get("name"),
            last_updated=blob_metadata.get(
                "last_updated", datetime(year=1, month=1, day=1)
            ),
            size=blob_metadata.get("size", 0),
            content_type=blob_metadata.get("content_type"),
            path=blob_metadata.get("path", ""),
            connector_type=blob_metadata.get("connector_type"),
            duration=blob_metadata.get("duration", None),
        )

    def __hash__(self) -> int:
        return hash(
            (self.source_id, self.name, self.last_updated, self.size, self.content_type)
        )


class SharepointFolder(BaseModel):
    id: str
    name: str
    children: dict[str, Union["SharepointFolder", SharepointFile]] = {}


class SharepointDrive(BaseModel):
    id: str
    name: str
    root: SharepointFolder


class SharepointPage(DomainExplorerBlobMetadata):
    parent: str | None = None

    @classmethod
    def from_blob(cls, blob: Blob) -> "SharepointPage":
        blob_metadata = blob.metadata
        if blob_metadata is None:
            blob_metadata = {}
        return SharepointPage(
            source_id=blob_metadata.get("source_id"),
            name=blob_metadata.get("name"),
            last_updated=blob_metadata.get(
                "last_updated", datetime(year=1, month=1, day=1)
            ),
            parent=blob_metadata.get("parent", None),
            path=blob_metadata.get("path"),
            connector_type=blob_metadata.get("connector_type"),
            link=blob_metadata.get("link"),
            content_type=blob_metadata.get("content_type"),
        )

    def __hash__(self) -> int:
        return hash(
            (
                self.source_id,
                self.name,
                self.last_updated,
                self.parent,
                self.connector_type,
            )
        )


class SharepointSiteIndex(BaseModel):
    id: str
    name: str
    drives: list[SharepointDrive] = []
    pages: list[SharepointPage] = []

    @classmethod
    def from_site(cls, site: Site) -> "SharepointSiteIndex":
        drives = []
        for d in site.drives:
            drives.append(
                SharepointDrive(
                    id=d.id,
                    name=d.name,
                    root=SharepointFolder(id=d.root.id, name=d.root.name, children={}),
                )
            )
        return SharepointSiteIndex(id=site.id, name=site.name, drives=drives)


class SharepointDriveFile(SharepointFile):
    drive_name: str
    drive_id: str
    prefix: str

    @classmethod
    def from_blob(cls, blob: Blob) -> "SharepointDriveFile":
        blob_metadata = blob.metadata
        if blob_metadata is None:
            blob_metadata = {}
        return SharepointDriveFile(
            drive_name=blob_metadata.get("drive_name", ""),
            drive_id=blob_metadata.get("drive_id", ""),
            prefix=blob_metadata.get("prefix", ""),
            source_id=blob_metadata.get("source_id", ""),
            name=blob.name.rsplit("/", 1)[-1] if isinstance(blob.name, str) else "",
            last_updated=blob_metadata.get(
                "last_updated", datetime(year=1, month=1, day=1)
            ),
            size=blob.size if isinstance(blob.size, int) else 0,
            content_type=blob_metadata.get("content_type", ""),
            path=blob_metadata.get("path", ""),
            connector_type=blob_metadata.get("connector_type", ""),
            link=blob_metadata.get("link"),
            duration=blob_metadata.get("duration", None),
        )

    def to_blob(self, drive_path: str, bucket: Bucket) -> Blob:
        prefix = self.prefix if not self.prefix.startswith("/") else self.prefix[1:]
        return bucket.get_blob(
            blob_name="/".join(
                [
                    drive_path,
                    self.drive_name,
                    prefix,
                    self.name,
                ]
            )
        )

    def get_metadata(self) -> dict[str, str]:
        return {
            "drive_name": self.drive_name,
            "drive_id": self.drive_id,
            "prefix": self.prefix,
            "source_id": self.source_id,
            "last_updated": self.last_updated.isoformat(),
            "content_type": self.content_type,
            "connector_type": self.connector_type,
        }

    def __hash__(self) -> int:
        return hash(
            (
                self.drive_id,
                self.prefix,
                self.source_id,
                self.name,
                self.last_updated,
                self.size,
                self.content_type,
            )
        )
