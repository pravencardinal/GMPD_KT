from logging import Logger

from google.api_core.client_options import ClientOptions
from google.api_core.exceptions import GoogleAPICallError, NotFound
from google.cloud.discoveryengine_v1 import (
    CreateDataStoreRequest,
    DataStore,
    DataStoreServiceClient,
    GetDataStoreRequest,
)
from google.cloud.storage import Blob, Bucket, Client
from pydantic import BaseModel

from ingestion.models.config import GCSStorageConfig
from ingestion.models.storage import DataStoreDocument

class Connector(BaseModel):
    """Base class for Connectors.

    Each Connector implements a pattern to populate a single Discovery Engine Data Store."""

    domain: str
    project: str
    gcs_storage_config: GCSStorageConfig
    _name: str
    data_store_id: str = None
    gcs_prefix: str = "domains"
    chunk_size: int = 500

    def get_logger(self, logger: Logger) -> Logger:
        return logger.getChild(self._name)

    def get_domain_path(self) -> str:
        return "/".join([self.gcs_prefix, self.domain])

    def get_storage_client(self) -> Client:
        return Client(project=self.gcs_storage_config.project)

    def get_bucket(self) -> Bucket:
        return self.get_storage_client().get_bucket(
            bucket_or_name=self.gcs_storage_config.bucket_name
        )

    def get_data_store_documents(self) -> list[DataStoreDocument]: ...

    def get_or_create_data_store_metadata_blob(self) -> Blob: ...

    def get_data_store(self, project: str, location: str) -> DataStore: ...

    def get_or_create_data_store(self, logger: Logger, project: str, location: str):
        data_store: DataStore = self.get_data_store(project=project, location=location)
        data_store_client = DataStoreServiceClient()
        try:
            logger.info("Getting data store...")
            existing_data_store = data_store_client.get_data_store(
                request=GetDataStoreRequest(name=data_store.name)
            )
            if (
                existing_data_store.document_processing_config.chunking_config
                != data_store.document_processing_config.chunking_config
            ):
                raise ValueError(
                    "Existing data store chunking_config not "
                    + "the same as defined chunking_config"
                )
            if (
                existing_data_store.document_processing_config.default_parsing_config
                != data_store.document_processing_config.default_parsing_config
            ):
                raise ValueError(
                    "Existing data store default_parsing_config not "
                    + "the same as defined default_parsing_config"
                )
            data_store = existing_data_store
            logger.info("Data store retrieved")
        except NotFound:
            logger.info("Data store doesn't exist, creating data store...")
            # Make the request
            create_data_store_request = CreateDataStoreRequest(
                parent=data_store_client.collection_path(
                    project=project,
                    location=location,
                    collection="default_collection",
                ),
                data_store=data_store,
                data_store_id=self.data_store_id,
            )
            operation = data_store_client.create_data_store(
                request=create_data_store_request
            )
            data_store = operation.result()
        return data_store