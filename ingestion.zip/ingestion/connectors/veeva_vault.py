import asyncio
import re
from datetime import datetime
from logging import Logger
from typing import Any, Dict

import aiohttp
from google.cloud.discoveryengine_v1 import (
    DataStore,
    DataStoreServiceClient,
    DocumentProcessingConfig,
    IndustryVertical,
)
from google.cloud.storage import Blob
from pydantic import computed_field

from ingestion.connectors.base_connector import Connector
from ingestion.models.config import VeevaVaultConfig
from ingestion.models.storage import DataStoreDocument
from ingestion.models.veeva_vault import VeevaVaultFile
from ingestion.storage.discovery_engine import (
    ImportType,
    blob_is_discovery_engine_compatible,
    blob_to_metadata,
)


class VeevaVaultConnector(Connector):
    """
    Our connector to the Veeva Vault API.
    Meant to create a data store for a given VQL Query of documents.

    Artifacts:
        Base path:  'domains/{domain}'
        Indexes:    {base path}/metadata/index.json
        Files:      {base path}/raw/{file-name}/...
    """

    veeva_vault_config: VeevaVaultConfig
    import_type: ImportType = ImportType.LAYOUT_CHUNKING
    _name: str = "veeva-vault-connector"

    # ----- Pipeline GCS Artifact Paths ------
    @computed_field
    @property
    def connector_path(self) -> str:
        return "/".join([self.get_domain_path(), self._name])

    @computed_field
    @property
    def metadata_path(self) -> str:
        return self.connector_path + "/metadata"

    @computed_field
    @property
    def documents_path(self) -> str:
        return self.connector_path + "/docs"

    @computed_field
    @property
    def index_path(self) -> str:
        return self.metadata_path + "/index.jsonl"

    @computed_field
    @property
    def last_successful_run_path(self) -> str:
        return self.metadata_path + "/last_successful_run.txt"

    @computed_field
    @property
    def data_store_metadata_path(self) -> str:
        return self.metadata_path + "/data_store_documents.jsonl"

    # ----- Veeva Vault -----
    async def get_veeva_session(self) -> str:
        """
        Returns a Veeva Vault session to be used in API calls.
        """

        async with aiohttp.ClientSession() as session:
            async with session.post(
                self.veeva_vault_config.identity_auth_url,
                data={
                    "grant_type": "password",
                    "username": self.veeva_vault_config.username,
                    "password": self.veeva_vault_config.password,
                    "client_id": self.veeva_vault_config.client_id,
                    "scope": "openid profile",
                },
            ) as identity_response:
                access_token = (await identity_response.json())["access_token"]

            veeva_auth_url = f"https://login.veevavault.com/auth/oauth/session/{self.veeva_vault_config.oauth_oidc_profile_id}"

            async with session.post(
                veeva_auth_url,
                headers={"Authorization": f"Bearer {access_token}"},
                data={
                    "vaultDNS": "cardinalhealthsbx-cah-quality-sbx.veevavault.com",
                    "client_id": self.veeva_vault_config.client_id,
                },
            ) as veeva_response:
                veeva_session = (await veeva_response.json())["sessionId"]

        return veeva_session

    def parse_filename(self, header_filename: str) -> str:
        """
        Returns the filename from the content-disposition header.

        Example header filename to be parsed:
            attachment;filename*=UTF-8''Test.pdf
        Example parsed filename returned:
            Test.pdf
        """
        match = re.search(r"filename\*=(.*)", header_filename)
        # Strip filename from the content-disposition header
        filename = match.group(1).split("''")[1]
        # Convert any URL encoded characters
        filename = re.sub(
            r"%([0-9a-fA-F]{2})", lambda m: chr(int(m.group(1), 16)), filename
        )
        return filename

    async def upload_veeva_doc_to_gcs(
        self,
        logger: Logger,
        veeva_doc: VeevaVaultFile,
        veeva_session: str,
        session: aiohttp.ClientSession,
    ) -> None:
        """
        Async function to fetch a single doc from Veeva Vault and upload it to the GCS bucket.
        """
        logger.debug(
            f"Processing file {veeva_doc.name}, source id: {veeva_doc.source_id}"
        )
        doc_url = f"https://{self.veeva_vault_config.vaultDNS}/api/v24.1/objects/documents/{veeva_doc.source_id}/renditions/viewable_rendition__v"
        bucket = self.get_bucket()
        async with session.get(
            doc_url, headers={"Authorization": veeva_session}
        ) as response:
            if response.headers.get("Content-Type").startswith(
                "application/octet-stream"
            ):
                doc_blob = bucket.blob(veeva_doc.path)
                with doc_blob.open("wb") as f:
                    f.write(await response.read())
                doc_blob.metadata = veeva_doc.model_dump()
                doc_blob.content_type = veeva_doc.content_type
                doc_blob.patch()
                # except Exception as e:
                #     logger.info(f"Error processing file {veeva_doc.link}: {e}.")

    # ----- Google Cloud Storage -----
    def get_last_successful_run(self) -> str | None:
        bucket = self.get_bucket()
        last_successful_run_blob = bucket.get_blob(self.last_successful_run_path)

        return (
            last_successful_run_blob.download_as_text()
            if last_successful_run_blob
            else None
        )

    def get_or_create_index_blob(self) -> Blob:
        site_index_blob = self.get_bucket().get_blob(self.index_path)
        if site_index_blob is None:
            site_index_blob = self.get_bucket().blob(self.index_path)
        return site_index_blob

    def get_or_create_data_store_metadata_blob(self) -> Blob:
        data_store_metadata_blob = self.get_bucket().get_blob(
            self.data_store_metadata_path
        )
        if data_store_metadata_blob is None:
            data_store_metadata_blob = self.get_bucket().blob(
                self.data_store_metadata_path
            )
        return data_store_metadata_blob

    # ----- Pydantic Artifacts -----

    # ----- Data Store Integration -----
    def get_data_store_documents(self) -> list[DataStoreDocument]:
        bucket = self.get_bucket()
        # Get file blobs
        gcs_files = list(bucket.list_blobs(match_glob=self.documents_path + "/**/*.*"))
        # Filter blobs for data store ingestion compatibility
        return [
            blob_to_metadata(blob)
            for blob in gcs_files
            if blob_is_discovery_engine_compatible(blob, import_type=self.import_type)
        ]

    def get_data_store(self, project: str, location: str) -> DataStore:
        data_store_client = DataStoreServiceClient()
        data_store_path = data_store_client.data_store_path(
            project=project,
            location=location,
            data_store=self.data_store_id,
        )
        return DataStore(
            name=data_store_path,
            display_name=self.data_store_id,
            industry_vertical=IndustryVertical.GENERIC,
            solution_types=[],
            content_config=DataStore.ContentConfig.CONTENT_REQUIRED,
            document_processing_config=DocumentProcessingConfig(
                chunking_config=DocumentProcessingConfig.ChunkingConfig(
                    layout_based_chunking_config=DocumentProcessingConfig.ChunkingConfig.LayoutBasedChunkingConfig(
                        chunk_size=500, include_ancestor_headings=True
                    )
                ),
                default_parsing_config=DocumentProcessingConfig.ParsingConfig(
                    layout_parsing_config=DocumentProcessingConfig.ParsingConfig.LayoutParsingConfig()
                ),
            ),
        )

    # ----- Tasks -----
    async def index(self, logger: Logger, query: str) -> None:
        veeva_session = await self.get_veeva_session()
        bucket = self.get_bucket()
        QUERY_URL = f"https://{self.veeva_vault_config.vaultDNS}/api/v24.1/query"
        logger.info("Getting doc index from Veeva Vault.")
        async with aiohttp.ClientSession() as session:
            async with session.post(
                QUERY_URL,
                headers={
                    "Authorization": veeva_session,
                    "X-VaultAPI-DescribeQuery": "true",
                },
                data={"q": query},
            ) as response:
                query_response: Dict[str, Any] = await response.json()

        veeva_docs: list[VeevaVaultFile] = []
        print(query_response.get("data"))
        for doc in query_response.get("data"):
            doc: Dict[str, Any] = doc
            doc_number = doc.get("document_number__v")
            doc_name = str(doc.get("name__v")).replace("\n", " ")
            veeva_docs.append(
                VeevaVaultFile(
                    source_id=str(doc.get("id")),
                    name=f"{doc_number} {doc_name.replace('/', '-')}",
                    document_number=doc.get("document_number__v"),
                    path=f"{self.documents_path}/{doc_number} {doc_name.replace('/', '-')}.pdf",
                    connector_type="veeva-vault-connector",
                    last_updated=doc.get("version_modified_date__v", datetime.now()),
                    content_type="application/pdf",
                    link=f"https://{self.veeva_vault_config.vaultDNS}/ui/#doc_info/{str(doc.get('id'))}",
                )
            )

        logger.info(f"Writing {len(veeva_docs)} docs to the GCS index.")
        index_blob = bucket.get_blob(self.index_path)
        if index_blob is None:
            index_blob = bucket.blob(self.index_path)

        with index_blob.open("w") as f:
            for veeva_doc in veeva_docs:
                f.write(veeva_doc.model_dump_json() + "\n")
        logger.info("Done.")

    async def mirror_docs_to_gcs(self, logger: Logger) -> None:
        veeva_session = await self.get_veeva_session()
        bucket = self.get_bucket()

        # Get doc index
        logger.info("Getting index from GCS.")
        index_blob = bucket.blob(self.index_path)
        index_data = index_blob.download_as_text()

        indexed_veeva_vault_files: list[VeevaVaultFile] = []
        for line in index_data.splitlines():
            if line.strip():
                indexed_veeva_vault_files.append(
                    VeevaVaultFile.model_validate_json(line)
                )

        logger.info("Getting list of blobs currently in GCS.")
        gcs_files = [
            VeevaVaultFile.from_blob(blob)
            for blob in bucket.list_blobs(match_glob=self.documents_path + "/**/*.*")
        ]

        new_veeva_vault_files = list(set(indexed_veeva_vault_files) - set(gcs_files))

        files_to_delete = list(set(gcs_files) - set(indexed_veeva_vault_files))

        if len(files_to_delete) > 0:
            logger.info(
                f"Deleting {len(files_to_delete)} files from GCS that are not in index."
            )

            blobs_to_delete = []
            for f in files_to_delete:
                logger.debug(f"Marking file {f.name} for destruction.")
                blobs_to_delete.append(bucket.get_blob(f.path))

            if len(blobs_to_delete) > 0:
                logger.info("Deleting pages from GCS that are not in page index...")
                bucket.delete_blobs(blobs=blobs_to_delete)

        if len(new_veeva_vault_files) > 0:
            logger.info(f"Writing {len(new_veeva_vault_files)} new documents to GCS.")
            async with aiohttp.ClientSession(
                headers={"Authorization": veeva_session}
            ) as session:
                tasks = [
                    self.upload_veeva_doc_to_gcs(
                        logger=logger,
                        veeva_doc=veeva_doc,
                        veeva_session=veeva_session,
                        session=session,
                    )
                    for veeva_doc in new_veeva_vault_files
                ]
                await asyncio.gather(*tasks)

        logger.info("Done.")
