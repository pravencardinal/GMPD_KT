from datetime import datetime
from logging import Logger
from pathlib import Path
from typing import List
from urllib.parse import unquote

from bs4 import BeautifulSoup, Tag
from google.cloud.discoveryengine_v1 import (
    DataStore,
    DataStoreServiceClient,
    DocumentProcessingConfig,
    IndustryVertical,
)
from google.cloud.storage import Blob, Bucket
from joblib import Parallel, delayed
from pydantic import computed_field

from ingestion.connectors.base_connector import Connector
from ingestion.models.config import ConfluenceConfig, DatabaseConfig, GCPConfig
from ingestion.models.confluence import ConfluenceDocument
from ingestion.models.storage import DataStoreDocument
from ingestion.sources.confluence import (
    ConfluenceServerAPI,
    get_all_confluence_space_pages,
    get_confluence_document,
    include_page,
    make_document_blob_name,
)
from ingestion.storage.discovery_engine import (
    ImportType,
    blob_is_discovery_engine_compatible,
    blob_to_metadata,
)


def get_and_write_confluence_page(
    document: ConfluenceDocument,
    api: ConfluenceServerAPI,
    expand: List[str],
    prefix: str,
    bucket: Bucket,
) -> None:
    """Get a document from Confluence via the API, write it to a GCS bucket.

    :param document: ConfluenceDocument object containing information about the document to get.
    :type document: ConfluenceDocument
    :param api: ConfluenceServerAPI object to use to interact with the API.
    :type api: ConfluenceServerAPI
    :param prefix: Prefix to use for the downloaded object when writing to GCS.
    :type prefix: str
    :param bucket: GCS bucket to write to.
    :type bucket: storage.Bucket
    """
    get_document_response = api.get(
        f"/rest/api/content/{document.source_id}?expand={','.join(expand)}"  # body.export_view,version"
    )
    document_with_body = get_confluence_document(
        page=get_document_response.json(), prefix=prefix
    )
    blob_name = make_document_blob_name(
        document_with_body.name, prefix=prefix, suffix=".html"
    )
    blob = bucket.blob(blob_name=blob_name)
    blob.upload_from_string(document_with_body.body.export_view.value)
    document_with_body.body = None
    document_with_body.last_updated = document_with_body.last_updated
    blob.metadata = document_with_body.model_dump()
    blob.patch()


def download_confluence_pages(
    documents: List[ConfluenceDocument],
    api: ConfluenceServerAPI,
    expand: List[str],
    prefix: str,
    bucket: Bucket,
    n_jobs: int = 5,
) -> None:
    """Download documents from Confluence.

    :param documents: List of ConfluenceDocument objects. Objects in this list contain the information needed to get a single document from the Confluence API.
    :type documents: List[ConfluenceDocument]
    :param api: API object to use to interact with the ConfluenceAPI.
    :type api: ConfluenceServerAPI
    :param prefix: Prefix to use for the downloaded object when writing to GCS.
    :type prefix: str
    :param bucket: GCS bucket to write to.
    :type bucket: storage.Bucket
    """
    # Download only those links not already downloaded
    # This is rate-limited so be careful with how many threads you create
    Parallel(n_jobs=n_jobs, prefer="threads", verbose=5)(
        delayed(get_and_write_confluence_page)(doc, api, expand, prefix, bucket)
        for doc in documents
    )


def get_page_blobs_to_remove(
    confluence_pages: List[ConfluenceDocument], blobs: List[Blob]
) -> List[Blob]:
    """Given a list of confluence documents and gcs blobs for those documents,
    determine which blobs whose source page no longer exists.

    Args:
        confluence_pages: A list of ConfluencePages from our index.
        blobs: A list of blobs currently in our bucket.

    Returns:
        A list of blobs to delete.
    """
    confluence_page_titles = set([p.name for p in confluence_pages])
    blob_titles = set([unquote(Path(b.name).stem) for b in blobs])
    removed_blob_titles = blob_titles - confluence_page_titles
    return [b for b in blobs if unquote(Path(b.name).stem) in removed_blob_titles]


def get_pages_that_changed(
    confluence_pages: List[ConfluenceDocument], blobs: List[Blob]
) -> List[ConfluenceDocument]:
    """Filter pages from our index for those we have yet to download,
    or those that are updated.

    Args:
        confluence_pages: A list of ConfluencePage instances from our index jsonl file.
        blobs: A list of blobs currently written to GCS.

    Returns:
        A list of ConfluencePage instances that we have to download from Confluence."""
    # New blobs
    if confluence_pages is None:
        confluence_pages = []
    if blobs is None:
        blobs = []
    blob_info = {
        unquote(Path(blob.name).stem): {
            "when": blob.metadata.get("last_updated", None),
            "version": blob.metadata.get("version_number", None),
        }
        if isinstance(blob.metadata, dict)
        else None
        for blob in blobs
    }
    new_pages = [page for page in confluence_pages if page.name not in blob_info.keys()]
    updated_pages = [
        page
        for page in confluence_pages
        if page.name in blob_info.keys()
        and blob_info.get(page.name) != page.last_updated.isoformat()
    ]
    return list(set(new_pages + updated_pages))


class ConfluenceConnector(Connector):
    """Our connector to the Confluence API. Meant to create a stage data for ingestion into a Data Store for a single Confluence Site.

    Artifacts:
        Base path:      `domains/{domain}/sharepoint-connector/{site_title}
        Indexes:        {base path}/metadata
        Pages:          {base path}/pages/...
    """

    site_key: str
    ignore_paths: list[str] = []
    confluence_config: ConfluenceConfig
    gcp_config: GCPConfig
    database_config: DatabaseConfig
    _name: str = "confluence-connector"
    import_type: ImportType = ImportType.DEFAULT

    # ----- Pipeline GCS Artifact Paths -----
    @computed_field
    @property
    def connector_path(self) -> str:
        return "/".join([self.get_domain_path(), self._name, self.site_key])

    @computed_field
    @property
    def metadata_path(self) -> str:
        return self.connector_path + "/metadata"

    @computed_field
    @property
    def page_index_path(self) -> str:
        return self.metadata_path + "/pages.jsonl"

    @computed_field
    @property
    def page_path(self) -> str:
        return self.connector_path + "/confluence_pages"

    @computed_field
    @property
    def page_elements_path(self) -> str:
        return self.connector_path + "/confluence_pages_elements"

    @computed_field
    @property
    def page_chunks_path(self) -> str:
        return self.connector_path + "/confluence_pages_chunks"

    @computed_field
    @property
    def page_embeddings_path(self) -> str:
        return self.connector_path + "/confluence_pages_embeddings"

    @computed_field
    @property
    def data_store_metadata_path(self) -> str:
        return self.metadata_path + "/data_store_documents.jsonl"

    # ----- Google Cloud Storage -----
    def get_or_create_data_store_metadata_blob(self) -> Blob:
        data_store_metadata_blob = self.get_bucket().get_blob(
            self.data_store_metadata_path
        )
        if data_store_metadata_blob is None:
            data_store_metadata_blob = self.get_bucket().blob(
                self.data_store_metadata_path
            )
        return data_store_metadata_blob

    def get_chunk_and_embedding_blobs(self) -> dict[str, dict[str, Blob]]:
        chunk_and_embedding_blobs: dict[str, dict[str, Blob]] = {}
        bucket = self.get_bucket()
        for blob in bucket.list_blobs(match_glob=self.page_chunks_path + "/**/*.json"):
            blob_file_name = Path(blob.name).stem
            chunk_and_embedding_blobs[blob_file_name] = {"chunks": blob}
        for blob in bucket.list_blobs(
            match_glob=self.page_embeddings_path + "/**/*.json"
        ):
            blob_file_name = Path(blob.name).stem
            chunk_and_embedding_blobs[blob_file_name]["embeddings"] = blob
        return chunk_and_embedding_blobs

    # ----- Data Store Integration -----
    def get_data_store_documents(self) -> list[DataStoreDocument]:
        bucket = self.get_bucket()
        # Get file blobs
        html_pages = list(bucket.list_blobs(match_glob=self.page_path + "/**/*.html"))
        # Filter blobs for data store ingestion compatibility
        return [
            blob_to_metadata(blob)
            for blob in html_pages
            if blob_is_discovery_engine_compatible(blob, import_type=self.import_type)
        ]

    def get_data_store(self, project: str, location: str) -> DataStore:
        data_store_client = DataStoreServiceClient()
        data_store_path = data_store_client.data_store_path(
            project=project,
            location=location,
            data_store=self.data_store_id,
        )
        return DataStore(
            name=data_store_path,
            display_name=self.data_store_id,
            industry_vertical=IndustryVertical.GENERIC,
            solution_types=[],
            content_config=DataStore.ContentConfig.CONTENT_REQUIRED,
            document_processing_config=DocumentProcessingConfig(
                chunking_config=DocumentProcessingConfig.ChunkingConfig(
                    layout_based_chunking_config=DocumentProcessingConfig.ChunkingConfig.LayoutBasedChunkingConfig(
                        chunk_size=500, include_ancestor_headings=True
                    )
                ),
                default_parsing_config=DocumentProcessingConfig.ParsingConfig(
                    layout_parsing_config=DocumentProcessingConfig.ParsingConfig.LayoutParsingConfig()
                ),
            ),
        )

    # ----- Tasks -----
    def index(
        self,
        logger: Logger,
        overwrite: bool = False,
    ) -> None:
        """Search the Confluence API for all pages associated with the ICON space.
        Creates a jsonl file of all documents in the space, writes to GCS.

        Args:
            project: The GCP project to use.
            bucket_name: The name of the bucket to write to.
        """
        logger = self.get_logger(logger).getChild("index")
        bucket = self.get_bucket()
        index_space = True
        space_index_blob = bucket.get_blob(self.page_index_path)
        if space_index_blob is not None and not overwrite:
            if (
                space_index_blob.updated.isocalendar()
                >= datetime.today().date().isocalendar()
            ):
                logger.info(f"Index for space {self.site_key} already exists")
                index_space = False
        if not index_space:
            logger.info("Space already indexed today, returning")
            return
        logger.info("Indexing")
        api = ConfluenceServerAPI(access_token=self.confluence_config.access_token)
        # Index available pages
        logger.info("Indexing pages in Confluence")
        space_pages = get_all_confluence_space_pages(
            site_key=self.site_key,
            prefix=self.page_path,
            api=api,
            expand=["ancestors", "version"],
        )
        logger.info("Indexed {:,} pages".format(len(space_pages)))
        # Remove pages we ignore
        logger.info("Removing pages we must ignore.")
        if len(self.ignore_paths) > 0:
            space_pages = [
                p
                for p in space_pages
                if include_page(p, ignore_paths=self.ignore_paths)
            ]
            logger.info("{:,} pages after filtering".format(len(space_pages)))

        # Write pages
        logger.info("Writing page info to GCS")
        space_index_blob = bucket.get_blob(self.page_index_path)
        if space_index_blob is None:
            space_index_blob = bucket.blob(self.page_index_path)
        with space_index_blob.open("w") as f:
            for page in space_pages:
                f.write(page.model_dump_json(by_alias=True) + "\n")
        logger.info("Done")

    def mirror_pages(self, logger: Logger) -> None:
        """Update documents we are storing in GCS. Download pages we do not yet have.
        Remove pages that were deleted. Overwrite pages that were updated.

        Args:
            project: The GCP project to use.
            bucket_name: The name of the bucket to write to.
        """
        logger = self.get_logger(logger).getChild("mirror-pages")
        # Get index
        logger.info("Reading index...")
        bucket = self.get_bucket()
        space_index_blob = bucket.get_blob(self.page_index_path)
        if space_index_blob is None:
            raise FileNotFoundError(
                "Page index not found for space: {}".format(self.site_key)
            )
        confluence_pages = [
            ConfluenceDocument.model_validate_json(json_string)
            for json_string in space_index_blob.open("r").readlines()
        ]
        # Read already downloaded blobs
        logger.info("Indexing already downloaded documents...")
        page_blobs: list[Blob] = list(
            bucket.list_blobs(match_glob=self.page_path + "/**/*.html")
        )
        # Compare downloaded blobs to index
        logger.info("Determining update operations...")
        #   Get blobs to download (new or overwrite existing)
        pages_to_download = get_pages_that_changed(
            confluence_pages=confluence_pages, blobs=page_blobs
        )
        #   Get blobs to remove
        blobs_to_remove = get_page_blobs_to_remove(
            confluence_pages=confluence_pages, blobs=page_blobs
        )
        # Download blobs
        if len(pages_to_download) > 0:
            logger.info(f"Downloading {len(pages_to_download)} pages...")
            download_confluence_pages(
                documents=pages_to_download,
                api=ConfluenceServerAPI(
                    access_token=self.confluence_config.access_token
                ),
                expand=["body.export_view", "version"],
                prefix=self.page_path,
                bucket=bucket,
            )
        # Remove blobs
        if len(blobs_to_remove) > 0:
            storage_client = self.get_storage_client()
            logger.info(f"Removing f{len(blobs_to_remove)} blobs...")
            for blob in blobs_to_remove:
                blob.delete(client=storage_client)
        logger.info("Done")

    def trim_images(self, logger: Logger) -> None:
        """Some of the HTML files are too large because of image content.
        To handle this, we need to trim images out of files that are too large.
        We can do this with beautifulsoup.

        Args:
            project: The GCP project our data lives in.
            bucket_name: Bucket our data lives in.
        """
        logger = self.get_logger(logger).getChild("trim")
        bucket = self.get_bucket()

        html_blobs: list[Blob] = list(
            bucket.list_blobs(match_glob=self.page_path + "/**/*.html")
        )

        too_large_blobs = [blob for blob in html_blobs if blob.size > 2500000]
        if len(too_large_blobs) == 0:
            logger.info("No blobs to trim.")
            return
        else:
            logger.info(
                "Trimming images from {:,} HTML blobs...".format(len(too_large_blobs))
            )
            for blob in too_large_blobs:
                logger.info("Trimming {}...".format(blob.name))
                logger.debug("Blob size: {:,}".format(blob.size))
                soup = BeautifulSoup(blob.open("r").read(), "html.parser")
                images_to_trim: list[Tag] = soup.find_all("img")
                logger.debug(f"Found {len(images_to_trim)}...")
                for image in images_to_trim:
                    logger.debug(
                        "Trimming {:,} bytes...".format(len(image.encode("utf-8")))
                    )
                    image.decompose()
                try:
                    with blob.open("w") as f:
                        new_content = soup.prettify(formatter="html")
                        logger.info(
                            "Writing new html blob with blob size {:,}...".format(
                                len(new_content.encode("utf-8"))
                            )
                        )
                        f.write(new_content)
                except Exception as e:
                    if blob.exists():
                        blob.delete()
                    raise e


def get_blobs_to_remove(
    source_blobs: List[Blob], target_blobs: List[Blob]
) -> List[Blob]:
    """Given a list of target blobs that were computed based on a previous
    set of source blobs. Determine which of the target blobs had their source
    blob deleted. I.E. Return those target blobs whose source blob no longer
    exists.

    Args:
        source_blobs: A list of Blobs that will be used to produce target_blobs
        target_blobs: A list of blobs that were created based on source_blobs

    Returns:
        A list of blobs to delete.
    """
    source_blobs_info = {
        blob.name: {
            "when": blob.metadata.get("last_updated"),
            "version": blob.metadata.get("version_number"),
        }
        if isinstance(blob.metadata, dict)
        else None
        for blob in source_blobs
    }
    return [
        blob
        for blob in target_blobs
        if blob.name not in source_blobs_info.keys()
        or source_blobs_info.get(blob.name)
        != (
            {
                "when": blob.metadata.get("last_updated"),
                "version": blob.metadata.get("version_number"),
            }
            if isinstance(blob.metadata, dict)
            else None
        )
    ]


def get_blobs_that_changed(
    source_blobs: List[Blob], target_blobs: List[Blob]
) -> List[ConfluenceDocument]:
    """Filter pages from our index for those we have yet to download,
    or those that are updated.

    Args:
        confluence_pages: A list of ConfluencePage instances from our index jsonl file.
        blobs: A list of blobs currently written to GCS.

    Returns:
        A list of ConfluencePage instances that we have to download from Confluence."""
    if source_blobs is None:
        source_blobs = []
    if target_blobs is None:
        target_blobs = []
    source_blobs_info = {
        blob.name: {
            "when": blob.metadata.get("last_updated"),
            "version": blob.metadata.get("version_number"),
        }
        if isinstance(blob.metadata, dict)
        else None
        for blob in source_blobs
    }
    target_blobs_info = {
        blob.name: {
            "when": blob.metadata.get("last_updated"),
            "version": blob.metadata.get("version_number"),
        }
        if isinstance(blob.metadata, dict)
        else None
        for blob in target_blobs
    }
    new_blobs = [
        blob for blob in source_blobs if blob.name not in target_blobs_info.keys()
    ]
    updated_blobs = [
        blob
        for blob in source_blobs
        if blob.name in target_blobs_info.keys()
        and target_blobs_info.get(blob.name) != source_blobs_info.get(blob.name)
    ]
    added_blobs = set([blob.id for blob in new_blobs])
    changed_blobs = new_blobs
    for blob in updated_blobs:
        if blob.id not in added_blobs:
            changed_blobs.append(blob)
            added_blobs.add(blob.id)
    return changed_blobs
