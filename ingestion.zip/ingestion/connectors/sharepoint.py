import asyncio
from enum import Enum
from logging import Logger

from azure.identity import UsernamePasswordCredential
from google import genai
from google.cloud.discoveryengine_v1 import (
    DataStore,
    DataStoreServiceClient,
    DocumentProcessingConfig,
    IndustryVertical,
)
from google.cloud.storage import Blob
from httpx import AsyncClient, Limits
from msgraph import GraphRequestAdapter, GraphServiceClient
from msgraph_core import GraphClientFactory
from msgraph_core.authentication import AzureIdentityAuthenticationProvider
from pydantic import computed_field
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from ingestion.connectors.base_connector import Connector
from ingestion.models.config import GCPConfig, MicrosoftGraphConfig
from ingestion.models.microsoft.sharepoint import (
    SharepointDriveFile,
    SharepointPage,
    SharepointSiteIndex,
)
from ingestion.models.storage import DataStoreDocument
from ingestion.sources.microsoft.sharepoint import (
    get_sharepoint_site_id,
    index_sharepoint_site,
    retrieve_site_files,
    write_sharepoint_file_to_gcs,
    write_sharepoint_page_to_gcs,
)
from ingestion.storage.discovery_engine import (
    ImportType,
    blob_is_discovery_engine_compatible,
    blob_to_metadata,
)
from ingestion.utils.file_transfom import transcribe_file


class SharepointType(Enum):
    SITE = "sites"
    TEAMS = "teams"


class SharepointConnector(Connector):
    """Our connector to the Sharepoint API. Meant to create a data store for a single Sharepoint Site.

    Artifacts:
        Base path:  `domains/{domain}/sharepoint-connector/{site_title}
        Indexes:    {base path}/metadata
        Files:      {base path}/drives/{drive-name}/...
        Pages:      {base path}/pages/...
    """

    site_title: str
    graph_config: MicrosoftGraphConfig
    import_type: ImportType = ImportType.LAYOUT_CHUNKING
    _name: str = "sharepoint-connector"
    sites_or_teams: SharepointType = SharepointType.SITE

    # ----- Pipeline GCS Artifact Paths ------
    @computed_field
    @property
    def connector_path(self) -> str:
        return "/".join([self.get_domain_path(), self._name, self.site_title])

    @computed_field
    @property
    def metadata_path(self) -> str:
        return self.connector_path + "/metadata"

    @computed_field
    @property
    def site_index_path(self) -> str:
        return self.metadata_path + "/index.json"

    @computed_field
    @property
    def site_files_index_path(self) -> str:
        return self.metadata_path + "/files.jsonl"

    @computed_field
    @property
    def site_pages_index_path(self) -> str:
        return self.metadata_path + "/pages.jsonl"

    @computed_field
    @property
    def data_store_metadata_path(self) -> str:
        return self.metadata_path + "/data_store_documents.jsonl"

    @computed_field
    @property
    def site_drives_path(self) -> str:
        return self.connector_path + "/drives"

    @computed_field
    @property
    def site_pages_path(self) -> str:
        return self.connector_path + "/pages"

    @computed_field
    @property
    def site_transformed_path(self) -> str:
        return self.connector_path + "/transformed"

    # ----- MS Graph -----
    def get_credentials(self) -> UsernamePasswordCredential:
        return UsernamePasswordCredential(
            client_id=self.graph_config.client_id,
            username=self.graph_config.username,
            password=self.graph_config.password,
        )

    def get_graph_client(self, http1: bool = False) -> GraphServiceClient:
        if http1:
            request_adapter = GraphRequestAdapter(
                auth_provider=AzureIdentityAuthenticationProvider(
                    credentials=self.get_credentials(), scopes=self.graph_config.scopes
                ),
                client=GraphClientFactory.create_with_default_middleware(
                    client=AsyncClient(
                        http2=False,
                        limits=Limits(
                            max_connections=25
                        ),  # Too many connections can lead to memory issues (Bottleneck for http1)
                    )
                ),
            )

            graph_client = GraphServiceClient(request_adapter=request_adapter)

        else:  # Defaults to http2, trades client side memory issues for http2 race / multiplexing issues
            graph_client = GraphServiceClient(
                credentials=self.get_credentials(), scopes=self.graph_config.scopes
            )

        return graph_client

    def get_site_id(self) -> str:
        credentials = self.get_credentials()

        graph_client = self.get_graph_client()

        site_id = get_sharepoint_site_id(
            site_title=self.site_title,
            credentials=credentials,
            client=graph_client,
            sites_or_teams=self.sites_or_teams.value,
        )
        assert site_id is not None
        assert isinstance(site_id, str)
        return site_id

    # ----- Google Cloud Storage -----
    def get_or_create_site_index_blob(self) -> Blob:
        site_index_blob = self.get_bucket().get_blob(self.site_index_path)
        if site_index_blob is None:
            site_index_blob = self.get_bucket().blob(self.site_index_path)
        return site_index_blob

    def get_or_create_site_files_index_blob(self) -> Blob:
        site_files_index_blob = self.get_bucket().get_blob(self.site_files_index_path)
        if site_files_index_blob is None:
            site_files_index_blob = self.get_bucket().blob(self.site_files_index_path)
        return site_files_index_blob

    def get_or_create_site_pages_index_blob(self) -> Blob:
        site_pages_index_blob = self.get_bucket().get_blob(self.site_pages_index_path)
        if site_pages_index_blob is None:
            site_pages_index_blob = self.get_bucket().blob(self.site_pages_index_path)
        return site_pages_index_blob

    def get_or_create_data_store_metadata_blob(self) -> Blob:
        data_store_metadata_blob = self.get_bucket().get_blob(
            self.data_store_metadata_path
        )
        if data_store_metadata_blob is None:
            data_store_metadata_blob = self.get_bucket().blob(
                self.data_store_metadata_path
            )
        return data_store_metadata_blob

    # ----- Pydantic Artifacts -----
    def get_site_index(self) -> SharepointSiteIndex:
        return SharepointSiteIndex.model_validate_json(
            self.get_or_create_site_index_blob().open("r").read()
        )

    def get_site_index_files(self) -> list[SharepointDriveFile]:
        with self.get_or_create_site_files_index_blob().open("r") as io:
            site_drive_files = [
                SharepointDriveFile.model_validate_json(line) for line in io.readlines()
            ]
        return site_drive_files

    def get_site_index_pages(self) -> list[SharepointPage]:
        with self.get_or_create_site_pages_index_blob().open("r") as io:
            site_pages = [
                SharepointPage.model_validate_json(line) for line in io.readlines()
            ]
        return site_pages

    # ----- Data Store Integration -----
    def get_data_store_documents(self) -> list[DataStoreDocument]:
        bucket = self.get_bucket()
        # Get file blobs
        gcs_files = list(
            bucket.list_blobs(match_glob=self.site_drives_path + "/**/*.*")
        )
        # Get page blobs
        gcs_pages = list(
            bucket.list_blobs(match_glob=self.site_pages_path + "/**/*.html")
        )
        # Get transformed blobs
        gcs_transformed = list(
            bucket.list_blobs(match_glob=self.site_transformed_path + "**/*.*")
        )
        # Filter blobs for data store ingestion compatibility
        return [
            blob_to_metadata(blob)
            for blob in gcs_files + gcs_pages + gcs_transformed
            if blob_is_discovery_engine_compatible(blob, import_type=self.import_type)
        ]

    def get_data_store(self, project: str, location: str) -> DataStore:
        data_store_client = DataStoreServiceClient()
        data_store_path = data_store_client.data_store_path(
            project=project,
            location=location,
            data_store=self.data_store_id,
        )
        chunking_config = None
        # Chunking Enabled
        if self.import_type != ImportType.LAYOUT:
            chunking_config = DocumentProcessingConfig.ChunkingConfig(
                layout_based_chunking_config=DocumentProcessingConfig.ChunkingConfig.LayoutBasedChunkingConfig(
                    chunk_size=self.chunk_size, include_ancestor_headings=True
                )
            )
        return DataStore(
            name=data_store_path,
            display_name=self.data_store_id,
            industry_vertical=IndustryVertical.GENERIC,
            solution_types=[],
            content_config=DataStore.ContentConfig.CONTENT_REQUIRED,
            document_processing_config=DocumentProcessingConfig(
                chunking_config=chunking_config,
                default_parsing_config=DocumentProcessingConfig.ParsingConfig(
                    layout_parsing_config=DocumentProcessingConfig.ParsingConfig.LayoutParsingConfig()
                ),
            ),
        )

    # ----- Tasks -----
    def index(
        self,
        logger: Logger,
        drives: bool = True,
        drive_folders: dict[str, list[str]] | None = None,
        skip_folders: dict[str, list[str]] | None = None,
        pages: bool = True,
        http1: bool = False,
    ) -> None:
        logger = self.get_logger(logger).getChild("update-data-store")
        logger.info("Getting site id...")
        site_id = self.get_site_id()
        logger.info("Indexing site...")
        site_index = asyncio.run(
            index_sharepoint_site(
                site_id=site_id,
                client=self.get_graph_client(http1=http1),
                drives=drives,
                drive_folders=drive_folders,
                skip_folders=skip_folders,
                pages=pages,
                site_pages_blob_path_prefix=self.site_pages_path,
            )
        )
        logger.info("Writing index to gcs...")
        with self.get_or_create_site_index_blob().open("w") as f:
            f.write(site_index.model_dump_json())
        logger.info("Done")

        site_drive_files = retrieve_site_files(
            index=site_index,
            blob_prefix=self.site_drives_path,
        )
        logger.info("Writing site drive file index to gcs...")
        file_index_blob = self.get_or_create_site_files_index_blob()
        with file_index_blob.open("w") as io:
            for f in site_drive_files:
                io.write(f.model_dump_json())
                io.write("\n")
        logger.info("Writing site page index to gcs...")
        page_index_blob = self.get_or_create_site_pages_index_blob()
        with page_index_blob.open("w") as io:
            for p in site_index.pages:
                io.write(p.model_dump_json())
                io.write("\n")
        logger.info("Done")

    def mirror_drive_files(
        self, logger: Logger, http1: bool = False, concurrency: int = 10
    ) -> None:
        logger = self.get_logger(logger).getChild("mirror-drive-files")

        logger.info("Reading file index from gcs...")
        index_files = self.get_site_index_files()

        logger.info("Creating mirror manifests...")
        bucket = self.get_bucket()
        gcs_files = [
            SharepointDriveFile.from_blob(blob)
            for blob in bucket.list_blobs(match_glob=self.site_drives_path + "/**/*.*")
        ]

        new_drive_files = list(set(index_files) - set(gcs_files))

        files_to_delete = list(set(gcs_files) - set(index_files))

        blobs_to_delete = []
        for f in files_to_delete:
            logger.debug(f"Marking file {f.name} for destruction.")
            blobs_to_delete.append(bucket.get_blob(f.path))

        if len(blobs_to_delete) > 0:
            logger.info("Deleting files from gcs that are not in index...")
            bucket.delete_blobs(blobs=blobs_to_delete)

        if len(new_drive_files) > 0:
            logger.info("Downloading files to gcs...")
            if len(new_drive_files) > 0:
                logger.debug("There are {:,} new files".format(len(new_drive_files)))
            storage_client = self.get_storage_client()
            graph_client = self.get_graph_client(http1=http1)

            async def write_tasks():
                semaphore = asyncio.Semaphore(concurrency)  # limit concurrency

                @retry(
                    stop=stop_after_attempt(5),
                    wait=wait_exponential(multiplier=1, min=4, max=10),
                    retry=retry_if_exception_type(Exception),
                )
                async def bounded_write(f):
                    async with semaphore:
                        return await write_sharepoint_file_to_gcs(
                            file=f,
                            bucket=bucket,
                            storage_client=storage_client,
                            graph_client=graph_client,
                            blob_prefix=self.site_drives_path,
                            logger=logger,
                        )

                tasks = [bounded_write(f) for f in new_drive_files]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for res in results:
                    if isinstance(res, Exception):
                        logger.error(f"Exception: {type(res).__name__} - {res}")

            try:
                loop = asyncio.new_event_loop()
                loop.run_until_complete(write_tasks())
                loop.close()
            except Exception:
                logger.exception("Error mirroring drive files")

        logger.info("Done")

    def mirror_site_pages(self, logger: Logger, http1: bool = False) -> None:
        logger = self.get_logger(logger).getChild("mirror-site-pages")
        logger.info("Reading site pages index from gcs...")

        index_pages = self.get_site_index_pages()

        logger.info("Creating mirror manifests...")
        bucket = self.get_bucket()
        gcs_pages = [
            SharepointPage.from_blob(blob)
            for blob in bucket.list_blobs(
                match_glob=self.site_pages_path + "/**/*.html"
            )
        ]

        new_pages = list(set(index_pages) - set(gcs_pages))

        files_to_delete = list(set(gcs_pages) - set(index_pages))

        blobs_to_delete = []
        for f in files_to_delete:
            logger.debug(f"Marking file {f.name} for destruction.")
            blobs_to_delete.append(bucket.get_blob(f.path))

        if len(blobs_to_delete) > 0:
            logger.info("Deleting pages in gcs that are not in page index...")
            bucket.delete_blobs(blobs=blobs_to_delete)

        if len(new_pages) > 0:
            logger.info("Downloading pages...")
            if len(new_pages) > 0:
                logger.debug("There are {:,} new pages".format(len(new_pages)))
            site_id = self.get_site_id()
            storage_client = self.get_storage_client()
            graph_client = self.get_graph_client(http1=http1)
            write_tasks = [
                write_sharepoint_page_to_gcs(
                    site_id=site_id,
                    page=page,
                    bucket=bucket,
                    storage_client=storage_client,
                    graph_client=graph_client,
                    logger=logger,
                )
                for page in new_pages
            ]
            logger.debug("Writing {:,} pages to gcs...".format(len(write_tasks)))
            loop = asyncio.new_event_loop()
            loop.run_until_complete(asyncio.wait(write_tasks))
            loop.close()

        logger.info("Done")

    def transcribe_files(
        self, logger: Logger, transcription_types: list[str], concurrency: int = 5
    ) -> None:
        bucket = self.get_bucket()
        gcs_files = [
            SharepointDriveFile.from_blob(blob)
            for blob in bucket.list_blobs(match_glob=self.site_drives_path + "/**/*.*")
        ]

        gcs_transformed = [
            SharepointDriveFile.from_blob(blob)
            for blob in bucket.list_blobs(
                match_glob=self.site_transformed_path + "/**/*.*"
            )
        ]

        source_file_info = {file.source_id: file.content_type for file in gcs_files}
        transformed_ids = {file.source_id for file in gcs_transformed}

        files_to_delete = [
            gcs_transform
            for gcs_transform in gcs_transformed
            if gcs_transform.source_id not in source_file_info
            or not any(
                type in source_file_info[gcs_transform.source_id]
                for type in transcription_types
            )
        ]

        untransformed_files = [
            gcs_file
            for gcs_file in gcs_files
            if gcs_file.source_id not in transformed_ids
            and any(type in gcs_file.content_type for type in transcription_types)
        ]

        storage_client = self.get_storage_client()
        prov_id = GCPConfig(project=storage_client.project).provider_project_id
        genai_client = genai.Client(
            vertexai=True, project=prov_id, location="us-central1"
        )

        bucket = self.get_bucket()

        blobs_to_delete = []
        for f in files_to_delete:
            logger.debug(f"Marking file {f.name} for destruction.")
            blobs_to_delete.append(bucket.get_blob(f.path))

        if len(blobs_to_delete) > 0:
            logger.info("Deleting files from gcs that are not in index...")
            bucket.delete_blobs(blobs=blobs_to_delete)

        if len(untransformed_files) > 0:
            logger.info("Transcribing Files...")
            if len(untransformed_files) > 0:
                logger.debug(
                    "There are {:,} new files to transcribe".format(
                        len(untransformed_files)
                    )
                )

            async def transcribe_tasks():
                semaphore = asyncio.Semaphore(concurrency)  # limit concurrency

                async def bounded_transcribe(f):
                    async with semaphore:
                        return await transcribe_file(
                            file=f,
                            transformed_path=self.site_transformed_path,
                            storage_client=storage_client,
                            genai_client=genai_client,
                            bucket=bucket,
                            logger=logger,
                        )

                tasks = [bounded_transcribe(f) for f in untransformed_files]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for res in results:
                    if isinstance(res, Exception):
                        logger.error(f"Exception: {type(res).__name__} - {res}")

            try:
                loop = asyncio.new_event_loop()
                loop.run_until_complete(transcribe_tasks())
                loop.close()
            except Exception:
                logger.exception("Error transcribing files")
        logger.info("Done")
