import hashlib
import mimetypes
import os
from datetime import datetime, timezone
from typing import List

from google.cloud.discoveryengine_v1 import (
    DataStore,
    DataStoreServiceClient,
    DocumentProcessingConfig,
    IndustryVertical,
)
from pydantic import computed_field

from ingestion.connectors.base_connector import Connector
from ingestion.models.domain_explorer_blob import DomainExplorerBlobMetadata


class GCSConnector(Connector):
    """
    GCSConnector extends the base connector to handle
        - GCS file listing
        - Metadata model generation
        - Uploading metadata for Discovery Engine
        and managing ingestion lifecycle
    Artifacts:
        Base path:  'domains/{domain}'
        Indexes:    {base path}/metadata/index.json

    """

    domain: str
    project: str
    gcs_prefix: str = "domains"
    bucket_name: str

    # ----- Pipeline GCS Artifact Paths ------

    @computed_field
    @property
    def domain_path(self) -> str:
        "Full Domain path in GCS"
        return f"{self.gcs_prefix}/{self.domain}"

    @computed_field
    @property
    def index_path(self) -> str:
        "Discovery Engine index path"
        return f"{self.domain_path}/medatada/index.json"

    @computed_field
    @property
    def metadata_blob_path(self) -> str:
        "Directory for GCS metadata blob"
        return f"{self.domain_path}/metadata"

    def get_mime_type(self, filename: str) -> str:
        """
        Returns MIME type for a given file path using its filename extension
        """
        mime_type, _ = mimetypes.guess_type(filename)
        return mime_type or "application/octet-stream"

    def list_gcs_files(self, bucket_name: str, prefix: str) -> List[str]:
        """
        List all file paths under a specified GCS prefix, ignoring folders
        """
        client = self.get_storage_client()
        bucket = client.bucket(bucket_name)
        blobs = bucket.list_blobs(prefix=prefix)
        return [blob.name for blob in blobs if not blob.name.endswith("/")]

    # METADATA CREATION
    def generate_metadata_jsonl(
        self, bucket_name: str, domain: str, prefix: str
    ) -> str:
        """
        Generates and uploads a .jsonl file with metadata for each GCS file in the prefix.
        Each line represents a DomainExplorerBlobMetadata JSON object.
        Uploads this JSONL to the index path in GCS.

        Returns:
             GCS path to the metadata index file.
        """

        metadata_lines = []
        client = self.get_storage_client()
        bucket = client.bucket(bucket_name)
        file_paths = self.list_gcs_files(bucket_name, prefix)
        blob = bucket.blob(self.index_path)

        for gcs_path in file_paths:
            filename = os.path.basename(gcs_path)
            file_id = hashlib.md5(gcs_path.encode()).hexdigest()
            mime_type = self.get_mime_type(filename)

            # Create metadata model for the file
            metadata_model = DomainExplorerBlobMetadata(
                source_id=file_id,
                name=filename,
                path=gcs_path,
                connector_type="gcs-connector",
                last_updated=datetime.now(timezone.utc),
                content_type=mime_type,
            )

            metadata_lines.append(metadata_model.model_dump_json())

        # Combine all lines in to a single .jsonl string

        jsonl_content = "\n".join(metadata_lines)
        blob.upload_from_string(jsonl_content, content_type="application/json")
        return f"gs://{bucket_name}/{self.index_path}"

    def get_data_store(self, project: str, location: str) -> DataStore:
        """
        Fetches a data store from the discoveryengine API / AI Applications Google Service.

        Returns:
           DataStore object
        """

        data_store_client = DataStoreServiceClient()
        data_store_path = data_store_client.data_store_path(
            project=project,
            location=location,
            data_store=self.data_store_id,
        )
        return DataStore(
            name=data_store_path,
            display_name=self.data_store_id,
            industry_vertical=IndustryVertical.GENERIC,
            solution_types=[],
            content_config=DataStore.ContentConfig.CONTENT_REQUIRED,
            document_processing_config=DocumentProcessingConfig(
                chunking_config=DocumentProcessingConfig.ChunkingConfig(
                    layout_based_chunking_config=DocumentProcessingConfig.ChunkingConfig.LayoutBasedChunkingConfig(
                        chunk_size=500, include_ancestor_headings=True
                    )
                ),
                default_parsing_config=DocumentProcessingConfig.ParsingConfig(
                    layout_parsing_config=DocumentProcessingConfig.ParsingConfig.LayoutParsingConfig()
                ),
            ),
        )
