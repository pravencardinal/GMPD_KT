import json
from datetime import datetime, timedelta
from logging import Logger
from typing import List
from urllib.parse import unquote

import pandas as pd
from bs4 import BeautifulSoup
from google import genai
from google.genai import types
from pydantic import computed_field
from retry import retry
from sqlalchemy import URL, Engine, create_engine
from sqlalchemy_utils import create_database, database_exists
from sqlmodel import SQLModel

from ingestion.connectors.base_connector import Connector
from ingestion.models.config import DatabaseConfig, FeedlyConfig, GCPConfig
from ingestion.models.feedly import SalesCoPilotEntry
from ingestion.sources.feedly import (
    FeedlyAPI,
    get_all_stream_articles,
    get_specified_search_articles,
)


class FeedlyConnector(Connector):
    _name: str = "feedly-connector"
    feedly_config: FeedlyConfig
    database_config: DatabaseConfig

    # ----- Pipeline GCS Artifact Paths -----
    @computed_field
    @property
    def connector_path(self) -> str:
        return "/".join([self.get_domain_path(), "raw"])

    def write_articles_to_gcs(self, logger: Logger, articles: List[dict]):
        logger = self.get_logger(logger).getChild("index")
        bucket = self.get_bucket()

        # Check for duplicates within GCS bucket
        logger.info("Check GCS for duplicates")

        # all of the feedly ids that are currently in our bucket
        bucket_ids = [
            unquote(
                blob.path[
                    blob.path.rfind("raw%2F") + 6 : blob.path.rfind(".json")
                ].replace("-", "/")
            )
            for blob in bucket.list_blobs(prefix=self.connector_path)
        ]

        feedly_ids = [article["id"] for article in articles]
        new_ids = set(bucket_ids) ^ set(feedly_ids)
        non_duplicate_articles = [
            article for article in articles if article["id"] not in bucket_ids
        ]

        logger.info(f"Found {len(new_ids)} new articles from feedly")

        # Write articles to gcs
        logger.info("Writing article info to GCS")
        for article in non_duplicate_articles:
            blob = bucket.blob(
                f"{self.connector_path}/{article['id'].replace('/', '-')}.json"
            )
            blob.upload_from_string(json.dumps(article))
        return non_duplicate_articles

    def extract_article_content(
        self, logger: Logger, non_duplicate_articles: List[str], prompt_text: str
    ) -> List[str]:
        logger = self.get_logger(logger).getChild("index")

        # Extract info with llm
        logger.info("Extracting data from new articles")

        all_entries = []

        for article in non_duplicate_articles:
            all_entries.append(
                self.extract_with_llm(
                    logger, prompt_text, self.feedly_config.llm_model, article
                )
            )

        return all_entries

    @retry(tries=3, delay=30, backoff=30)
    def get_output(self, genai_client, llm_model: str, prompt: str):
        output = genai_client.models.generate_content(
            model=llm_model,
            contents=[prompt],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=SalesCoPilotEntry,
                safety_settings=[
                    types.SafetySetting(
                        category="HARM_CATEGORY_DANGEROUS_CONTENT",
                        threshold="BLOCK_NONE",
                    )
                ],
                temperature=0,
            ),
        )
        json_out = json.loads(output.text)

        return json_out

    def upload_to_database(self, logger: Logger, database: str, articles):
        logger = self.get_logger(logger).getChild("index")
        logger.info("Uploading extracted articles to database")

        df = pd.DataFrame.from_records(articles)
        df["job_timestamp"] = pd.Timestamp("now")

        engine = get_engine(self.database_config, database)

        df.to_sql("initial_extracted_data", engine, if_exists="append")

    def extract_with_llm(
        self, logger: Logger, prompt_text: str, llm_model: str, article
    ):
        prov_id = GCPConfig(
            project=self.get_storage_client().project
        ).provider_project_id
        genai_client = genai.Client(
            vertexai=True, project=prov_id, location="us-central1"
        )

        if "fullContent" in set(article.keys()):
            article_text = BeautifulSoup(
                article["fullContent"], "html.parser"
            ).get_text()
        elif "content" in set(article.keys()):
            article_text = BeautifulSoup(
                article["content"]["content"], "html.parser"
            ).get_text()
        elif "summary" in set(article.keys()):
            article_text = BeautifulSoup(
                article["summary"]["content"], "html.parser"
            ).get_text()
        else:
            logger.info("Keys for extracting text not found")
            logger.info(article.keys())
            logger.info(article)
            article_text = ""

        prompt = f"""
        {prompt_text}
        
        Article begins below:
        {article_text}
        """

        json_out = self.get_output(genai_client, llm_model, prompt)
        if json_out is None:
            json_out = {}

        try:
            json_out["article_url"] = article["alternate"][0]["href"]
            json_out["article_text"] = article_text
            json_out["article_publish_date"] = datetime.utcfromtimestamp(
                int(str(article["published"])[:-3])
            ).strftime("%Y-%m-%d")
            json_out["article_id"] = article["id"]
        except Exception:
            print(article.keys())
        return json_out

    def get_articles_stream(self, logger: Logger) -> List[str]:
        logger = self.get_logger(logger).getChild("index")
        logger.info("Fetching Data from Feedly")
        api = FeedlyAPI(api_key=self.feedly_config.access_token)
        stream_articles = get_all_stream_articles(self.feedly_config.feed_name, api)
        return stream_articles

    def get_articles_search(
        self, logger: Logger, older_than: timedelta, newer_than: timedelta, feed_params
    ) -> List[str]:
        logger = self.get_logger(logger).getChild("index")
        logger.info("Fetching Search Data from Feedly")
        api = FeedlyAPI(api_key=self.feedly_config.access_token)

        older_than_unix = str(
            int((datetime.today() - timedelta(days=older_than)).timestamp())
        )
        newer_than_unix = str(
            int((datetime.today() - timedelta(days=newer_than)).timestamp())
        )
        search_articles = get_specified_search_articles(
            api, older_than_unix, newer_than_unix, feed_params
        )

        return search_articles


def get_engine(database_config: DatabaseConfig, database: str) -> Engine:
    url = URL(
        drivername="postgresql+psycopg",
        username=database_config.username,
        password=database_config.password,
        host=database_config.host,
        port=database_config.port,
        database=database,
        query={},
    )
    engine = create_engine(url=url)
    if not database_exists(engine.url):
        create_database(engine.url)
    SQLModel.metadata.create_all(engine)

    return engine
