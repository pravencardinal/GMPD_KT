import json
import logging
from datetime import date, datetime, timedelta
from typing import List

from google.cloud.storage import Client

from ingestion.models.feedly import FeedlyStream
from ingestion.sources.feedly import FeedlyAPI


def latest(
    api: FeedlyAPI,
    streams: List[FeedlyStream],
    project: str,
    bucket_name: str,
    overwrite: bool,
    logger: logging.Logger,
    limit: int = float("inf"),
):
    logger = logging.getLogger(__name__).getChild("latest")
    client = Client(project=project)
    bucket = client.get_bucket(bucket_name)

    prefix = "navista/feedly/stream"
    today = date.today().strftime("%Y-%m-%d")

    for feedly_stream in streams:
        logger.info(
            "Getting current articles from stream: {}".format(feedly_stream.name)
        )
        blob_name = "/".join([prefix, feedly_stream.name, today, "articles.jsonl"])
        logger.info(
            "Writing to gcs://{bucket}/{name}".format(
                bucket=bucket_name, name=blob_name
            )
        )
        blob = bucket.get_blob(blob_name)
        if blob is not None and not overwrite:
            return
        if blob is None or overwrite:
            blob = bucket.blob(blob_name)
        logger.info(
            "Writing to gcs://{bucket}/{name}".format(
                bucket=bucket_name, name=blob_name
            )
        )
        written_articles = 0
        with blob.open("w") as f:
            for response in api.yield_stream(
                feedly_stream.details.stream_id, count=min(100, limit)
            ):
                response_items = response.json().get("items", [])
                num_response_items = len(response_items)
                logger.info("Writing {len:,} articles".format(len=num_response_items))
                f.write(json.dumps(response_items) + "\n")
                written_articles += num_response_items
                if written_articles >= limit:
                    break


def history(
    api: FeedlyAPI,
    streams: List[FeedlyStream],
    project: str,
    bucket_name: str,
    overwrite: bool,
    logger: logging.Logger,
    limit: int = float("inf"),
    days: int = 365,
):
    logger = logging.getLogger(__name__).getChild("history")
    client = Client(project=project)
    bucket = client.get_bucket(bucket_name)
    older_than_unix = str(int((datetime.today() - timedelta(days=30)).timestamp()))
    newer_than_unix = str(int((datetime.today() - timedelta(days=days)).timestamp()))

    prefix = "navista/feedly/search"

    for feedly_stream in streams:
        logger.info("Getting articles for stream: {}".format(feedly_stream.name))
        logger.info(
            "Getting articles older than: {}".format(
                datetime.fromtimestamp(float(older_than_unix)).strftime("%Y-%m-%d")
            )
        )
        logger.info(
            "Getting articles newer than: {}".format(
                datetime.fromtimestamp(float(newer_than_unix)).strftime("%Y-%m-%d")
            )
        )
        blob_name = "/".join(
            [
                prefix,
                feedly_stream.name,
                f"older-than-{older_than_unix}-newer-than-{newer_than_unix}",
                "articles.jsonl",
            ]
        )
        blob = bucket.get_blob(blob_name)
        if blob is not None and not overwrite:
            return
        if blob is None or overwrite:
            blob = bucket.blob(blob_name)
        logger.info(
            "Writing to gcs://{bucket}/{name}".format(
                bucket=bucket_name, name=blob_name
            )
        )
        written_articles = 0
        with blob.open("w") as f:
            for search_response in api.search_articles(
                query_json=feedly_stream.details.json_query,
                count=min(100, limit),
                newerThan=newer_than_unix,
                olderThan=older_than_unix,
            ):
                search_response_items = search_response.json().get("items", [])
                num_search_response_items = len(search_response_items)
                logger.info(
                    "Writing {len:,} articles".format(len=num_search_response_items)
                )
                for i in search_response_items:
                    f.write(json.dumps(i) + "\n")
                written_articles += num_search_response_items
                if written_articles >= limit:
                    break
