import json
import logging
from datetime import date
from typing import List

import pandas as pd
import requests
from google.cloud.storage import Client

from ingestion.models.edgar import EdgarFile
from ingestion.sources.edgar import (
    get_cik_submissions,
    get_edgar_files,
)


def index(project: str, bucket_name: str):
    """Index files to get from EDGAR."""
    logger = logging.getLogger(__name__).getChild("index")
    today = date.today()
    client = Client(project=project)
    bucket = client.get_bucket(bucket_name)
    directory = "navista/tickers"
    index_path = bucket.blob("navista/forms-index/" + f"{today.isoformat()}-index.csv")

    # Get CIKs
    if not index_path.exists():
        nasdaq_companies = pd.read_excel(
            "gs://" + bucket_name + "/" + directory + "/NASDAQ-pharma-2024.xlsx"
        )
        logger.info("Getting company tickers from EDGAR...")
        cik_ticker_uri = "https://www.sec.gov/files/company_tickers.json"
        cik_ticker_response = requests.get(
            cik_ticker_uri, headers={"User-Agent": "jake.bergren@cardinalhealth.com"}
        )
        if not cik_ticker_response.status_code == 200:
            raise ValueError(
                f"CIK ticker response is {cik_ticker_response.status_code}, with content: {cik_ticker_response.content}"
            )
        else:
            logger.info("Uploading ticker to CIK map to GCS...")
            ticker_blob = bucket.blob(
                f"navista/tickers/{today.isoformat()}-tickers.json"
            )
            cik_ticker_json = cik_ticker_response.json()
            if not ticker_blob.exists() or ticker_blob.size == 0:
                with ticker_blob.open("w") as b:
                    b.write(json.dumps(cik_ticker_json, indent=4))
            logger.info("Mapping ticker to CIK value...")
            cik_ticker_info = pd.DataFrame.from_dict(cik_ticker_json, orient="index")
            cik_ticker_info: dict[str, str] = cik_ticker_info.set_index(
                "ticker"
            ).cik_str.to_dict()
            nasdaq_companies.loc[:, "CIK"] = nasdaq_companies.Ticker.apply(
                lambda ticker: cik_ticker_info.get(ticker, None)
            )
        cik_list: List[str] = (
            nasdaq_companies.CIK.dropna()
            .astype(int)
            .astype(str)
            .apply(lambda cik: cik.zfill(10))
            .tolist()
        )
        logger.info(f"Getting submissions for {len(cik_list)} CIK values")
        submissions_path = directory + "/ submissions"
        submissions_blob = bucket.blob(submissions_path)
        if not submissions_blob.exists():
            logger.info("Making submissions directory...")
        # Query EDGAR for 10-K forms for each CIK
        cik_forms_frame_list = []
        for cik in cik_list:
            logger.info(f"Getting submissions for {cik}...")
            cik_submissions_path = submissions_path + "/" + cik + "-submissions.json"
            cik_submissions_blob = bucket.blob(cik_submissions_path)
            # JSON Response
            cik_submissions = get_cik_submissions(cik)
            # Save result
            with cik_submissions_blob.open("w") as f:
                f.write(json.dumps(cik_submissions, indent=4))

            # DataFrame
            cik_submissions = pd.DataFrame.from_dict(
                cik_submissions["filings"]["recent"], orient="columns"
            )
            # Filtered DataFrame
            cik_submissions = cik_submissions[
                cik_submissions.form.isin(["10-K", "10-Q"])
            ]
            if cik_submissions.shape[0] == 0:
                logger.info(f"No 10-K or 10-Q submissions for {cik}, continuing...")
                continue
            cik_submissions.loc[:, "CIK"] = cik
            cik_submissions = cik_submissions[
                [
                    "CIK",
                    "accessionNumber",
                    "filingDate",
                    "reportDate",
                    "acceptanceDateTime",
                    "form",
                    "fileNumber",
                    "filmNumber",
                    "size",
                    "primaryDocument",
                    "primaryDocDescription",
                ]
            ]
            if cik_submissions.shape[0] > 0:
                cik_forms_frame_list.append(cik_submissions)
        if len(cik_forms_frame_list) == 0:
            return []
        logger.info("Collecting all submissions into index...")
        cik_submissions = pd.concat(cik_forms_frame_list)
        # Save index to disc
        logger.info("Writing submissions index int gcs...")
        cik_submissions.to_csv(
            "gs://"
            + bucket_name
            + "/navista/forms-index/"
            + f"{today.isoformat()}-index.csv",
            index=False,
        )


def get(
    project: str,
    bucket_name: str,
    prefix: str = "navista/forms",
    workers: int = 5,
    limit: int = None,
):
    """Get files from EDGAR, upload to GCS bucket."""
    logger = logging.getLogger(__name__).getChild("get")
    # Init storage client
    storage_client = Client(project=project)
    bucket = storage_client.get_bucket(bucket_name)
    # Download 10-K forms
    today = date.today()
    index_path = (
        "gs://"
        + bucket_name
        + "/navista/forms-index/"
        + f"{today.isoformat()}-index.csv"
    )
    cik_submissions = pd.read_csv(index_path)

    if cik_submissions.shape[0] == 0:
        raise ValueError(f"index not found for {today.isoformat()}")
    logger.info(f"Loading index - {index_path}...")

    edgar_files: List[EdgarFile] = cik_submissions.apply(
        lambda row: EdgarFile(
            cik=row.CIK, form=row.form, accession_number=row.accessionNumber
        ),
        axis=1,
    ).tolist()

    if limit is not None:
        edgar_files = edgar_files[:limit]

    downloaded_files: List[EdgarFile] = get_edgar_files(
        edgar_files=edgar_files, prefix=prefix, bucket=bucket, workers=workers
    )
    # Return
    logging.info(f"Downloaded {len(downloaded_files)} edgar files")
    return [str(p) for p in downloaded_files]
