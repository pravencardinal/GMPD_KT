from typing import List

import requests

from ingestion.models.config import SalesforceConfig
from ingestion.models.salesforce import Agreement, SalesforceDocument


class SalesforceClient:
    def __init__(
        self,
        config: SalesforceConfig,
        uri: str = "https://cah01--stage.sandbox.my.salesforce.com",
    ) -> None:
        self.config = config
        self.uri = uri
        self._access_token = None

    def get_headers(self) -> dict:
        return {"Authorization": f"Bearer {self.get_access_token()}"}

    def get_access_token(self) -> str:
        if self._access_token is None:
            token_response = requests.post(
                self.uri + "/services/oauth2/token",
                params={
                    "grant_type": "password",
                    "username": self.config.username,
                    "client_id": self.config.client_id,
                    "client_secret": self.config.client_secret,
                    "password": self.config.password,
                },
            )
            self._access_token = token_response.json().get("access_token")
        return self._access_token


def get_agreements_from_apttus(
    client: SalesforceClient, subtype: str
) -> List[Agreement]:
    agreements: List[Agreement] = []

    query_response = requests.get(
        client.uri + "/services/data/v57.0/query",
        params={
            "q": f"select Id from Apttus__APTS_Agreement__c where Apttus__Subtype__c='{subtype}'"
        },
        headers=client.get_headers(),
    )

    new_agreements: List[dict] = query_response.json().get("records", [])
    agreements.extend(
        [
            Agreement(
                agreement_id=doc.get("Id"),
            )
            for doc in new_agreements
        ]
    )
    next_url = query_response.json().get("nextRecordsUrl", None)

    if len(agreements) > 0 and next_url is not None:
        while next_url is not None:
            query_response = requests.get(
                url=client.uri + next_url, headers=client.get_headers()
            )
            query_response_data = query_response.json()
            new_agreements = query_response_data.get("records", [])
            agreements.extend(
                [
                    Agreement(
                        agreement_id=doc.get("Id"),
                    )
                    for doc in new_agreements
                ]
            )

            next_url = query_response_data.get("nextRecordsUrl", None)

    return agreements


def get_salesforce_documents(
    client: SalesforceClient, agreement: Agreement, headers: dict
):
    if agreement.salesforce_documents is None:
        doc_version_id_response = requests.get(
            client.uri + "/services/data/v57.0/query",
            params={
                "q": "SELECT ContentDocumentId, ContentDocument.ContentModifiedDate, ContentDocument.Title FROM ContentDocumentLink WHERE LinkedEntityId = '{}'".format(
                    agreement.agreement_id
                )
            },
            headers=headers,
        )
        doc_version_id_records: List[dict] = doc_version_id_response.json().get(
            "records", []
        )
        version_documents = set()
        for content_document in doc_version_id_records:
            content_document_versions_response = requests.get(
                client.uri + "/services/data/v57.0/query",
                params={
                    "q": "SELECT Id, Title, ContentModifiedDate FROM ContentVersion WHERE ContentDocumentId = '{}'".format(
                        content_document.get("ContentDocumentId")
                    )
                },
                headers=headers,
            )
            for version_record in content_document_versions_response.json().get(
                "records", []
            ):
                version_documents.add(
                    SalesforceDocument(
                        id=version_record.get("Id"),
                        content_modified_date=version_record.get("ContentModifiedDate"),
                        title=version_record.get("Title"),
                    )
                )
        agreement.salesforce_documents = list(version_documents)
