from typing import Generator, List

import requests


class FeedlyAPI:
    def __init__(self, api_key: str) -> None:
        self._key = api_key
        self.stream_uri = "https://feedly.com/v3/streams/contents"
        self.search_uri = "https://feedly.com/v3/search/contents"
        self.headers = {"Authorization": "Bearer " + self._key}

    def _get_stream(self, stream_id: str, **params) -> requests.Response:
        params["streamId"] = stream_id
        return requests.get(
            self.stream_uri,
            params=params,
            headers=self.headers,
        )

    def yield_stream(
        self, stream_id: str, **params
    ) -> Generator[requests.Response, None, None]:
        continuation = None
        while True:
            if continuation is not None:
                params["continuation"] = continuation
            response = self._get_stream(stream_id=stream_id, **params)
            continuation = response.json().get("continuation", None)
            yield response
            if continuation is None:
                break

    def search(self, query_json: dict, **params) -> requests.Response:
        return requests.post(
            self.search_uri,
            headers={"Authorization": "Bearer " + self._key},
            params=params,
            json=query_json,
        )

    def search_articles(
        self, query_json: dict, **params
    ) -> Generator[requests.Response, None, None]:
        continuation = None

        while True:
            if continuation is not None:
                params["continuation"] = continuation

            response = self.search(query_json, **params)
            if response.status_code != 200:
                print(
                    "Error occurred while fetching articles. Please check your token and query."
                )
                return

            response_dict = response.json()
            continuation = response_dict.get("continuation")

            yield response
            if continuation is None:
                break

def get_all_stream_articles(
    stream_id: str,
    api: FeedlyAPI
) -> List[str]:
    documents = []
    for response in api.yield_stream(stream_id, count=100):
        response_items = response.json().get("items", [])
        documents.extend(response_items)
    return documents

def get_specified_search_articles(api: FeedlyAPI, older_than: str, newer_than: str, feed_search_body) -> List[str]:
    documents = []
    for response in api.search_articles(
        query_json=feed_search_body,
        count=100,
        newer_than=newer_than,
        older_than=older_than
    ):
        search_response_items = response.json().get("items", [])
        print(f"First search has {len(search_response_items)} items")
        documents.extend(search_response_items)
    return documents
    