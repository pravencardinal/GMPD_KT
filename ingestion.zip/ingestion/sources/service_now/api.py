from logging import getLogger
from typing import Generator, List

from backoff import expo, on_exception
from oauthlib.oauth2 import LegacyApplicationClient
from ratelimit import RateLimitException, limits, sleep_and_retry
from requests_oauthlib import OAuth2Session

from ingestion.models.config import ServiceNowAPIConfig
from ingestion.models.service_now import Record

logger = getLogger(name="service_now.api")

BASE_URI = "https://cardinalsand.service-now.com"


CLIENT = None
TOKEN = None

OAUTH_ENDPOINT = BASE_URI + "/oauth_token.do"


def update_token(new_token: str):
    """Update an OAuth2 Session token for the module.

    :param new_token: The new token.
    :type new_token: str
    """
    global TOKEN
    TOKEN = new_token
    logger.info("Updated OAUTH token")


def get_oauth(client_id: str) -> OAuth2Session:
    """Get an OAuth2Session given a client_id.

    :param client_id: Client ID for the API service.
    :type client_id: str

    :return: Initialized OAuth2Session.
    :rtype: OAuth2Session
    """
    global CLIENT, TOKEN
    if CLIENT is None:
        logger.info("Initializing OAuth2Session...")
        CLIENT = OAuth2Session(
            client=LegacyApplicationClient(client_id=client_id),
            token_updater=update_token,
            token=TOKEN,
        )
        logger.info("OAuth2Session initialized")
    return CLIENT


def get_oauth_token(
    client_id: str, client_secret: str, username: str, password: str
) -> str | None:
    """Get a new OAuth2 token given credentials.

    :param client_id: OAuth2 client_id
    :type client_id: str
    :param client_secret: OAuth2 client_secret
    :type client_secret: str
    :param username: OAuth2 username
    :type username: str
    :param password: OAuth2 password
    :type password: str

    :return: OAuth2 Token or None.
    :rtype: str or None
    """
    global TOKEN
    update_token(
        get_oauth(client_id).fetch_token(
            token_url=OAUTH_ENDPOINT,
            client_id=client_id,
            client_secret=client_secret,
            username=username,
            password=password,
        )
    )
    return TOKEN


@sleep_and_retry
@on_exception(expo, RateLimitException, max_tries=8)
@limits(calls=500, period=3600)
def rate_limit_service_now():
    """Passthrough function used to ratelimit interactions with the ServiceNow API."""
    pass


def get_sysparm_query(knowledge_base_ids: List[str]) -> str:
    """Format a ServiceNow Table sysparm query to get all documents in a list of
    knowledge bases.

    :param knowledge_base_ids: List of knowledge base ids.
    :type knowledge_base_ids: List[str]

    :return: A sysparm query.
    :rtype: str
    """
    return (
        "^OR".join([f"kb_knowledge_base={kb}" for kb in knowledge_base_ids])
        + "^active=true^workflow_state=published"
    )


def get_kb_articles(
    knowledge_base_ids: List[str],
    service_now_config: ServiceNowAPIConfig,
    batch_size: int = 1000,
    limit: int = None,
) -> Generator[List[Record], None, None]:
    """Get a list of knowledge base articles as a Generator.

    :param knowledge_base_ids: Knowledge Base ids.
    :type knowledge_base_ids: List[str]
    :param service_now_config: ServiceNow API params.
    :type service_now_config: ServiceNowAPIConfig
    :param batch_size: Number of records to retrieve at once. Defaults to 1000.
    :type batch_size: int
    :param limit: Limit of records to retrieve. Defaults to None.
    :type limit: int

    :return: A Generator of Knowledge Base record lists.
    :rtype: Generator[List[Record], None, None]
    """
    oauth = get_oauth(service_now_config.client_id)
    get_oauth_token(**service_now_config.dict())
    # Read articles from ServiceNow
    offset = 0
    sysparm_query = get_sysparm_query(knowledge_base_ids)
    while True:
        table_response = oauth.get(
            BASE_URI + "/api/now/table/kb_knowledge",
            params={
                "sysparm_no_count": True,
                "sysparm_query": sysparm_query,
                "sysparm_exclude_reference_link": True,
                "sysparm_limit": batch_size,
                "sysparm_offset": offset,
            },
        )
        table_response_dicts = table_response.json().get("result", [])
        table_records = [Record.validate(rec) for rec in table_response_dicts]
        if len(table_records) == 0:
            break
        offset += len(table_records)
        if isinstance(limit, int):
            if offset >= limit:
                break
        logger.info(f"Yielding {len(table_records)} Records...")
        yield table_records
    logger.info("Done yielding Records")
