from typing import Generator, List

from google.cloud.storage import Client
from joblib import Parallel, delayed

from ingestion.models.service_now import Record


def write_record_as_html_blob(
    record: Record, bucket_name: str, prefix: str, project: str = None
) -> str:
    """Write a ServiceNow knowledge base article as HTML.

    :param record: Knowledge Base record.
    :type record: Record
    :param bucket_name: Name of the GCP bucket to write to.
    :type bucket_name: str
    :param prefix: Blob name prefix.
    :type prefix: str
    :param project: GCP Project id. Defaults to None.
    :type project: str

    :return: The name of the written blob.
    :rtype: str
    """
    blob_name = prefix + f"/{record.sys_id}.html"
    storage_client = Client(project=project)
    bucket = storage_client.get_bucket(bucket_or_name=bucket_name)
    blob = bucket.blob(blob_name=blob_name)
    blob.upload_from_string(record.text)
    return blob_name


def write_records_as_html_blobs(
    record_generator: Generator[List[Record], None, None],
    bucket_name: str,
    prefix: str,
    project: str,
) -> List[str]:
    """Given a generator of Record lists, write them to GCS as blobs.

    :param record_generator: Generator of Record lists.
    :type record_generator: Generator[List[Record], None, None]
    :param bucket_name: Name of the bucket to write to.
    :type bucket_name: str
    :param prefix: Prefix to append to each blob. Analogous to a directory path.
    :type prefix: str
    :param project: GCP project id.
    :type project: str

    :return: List of written blob names.
    :rtype: List[str]
    """
    all_blob_names = []
    for records_list in record_generator:
        blob_names = Parallel(n_jobs=4)(
            delayed(write_record_as_html_blob)(record, bucket_name, prefix, project)
            for record in records_list
        )
        all_blob_names.extend(blob_names)
    return all_blob_names
