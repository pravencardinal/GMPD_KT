from datetime import datetime
from typing import Any, Dict, List
from urllib.parse import quote

from joblib import Parallel, delayed
from ratelimit import limits, sleep_and_retry
from requests import Response, Session
from requests.adapters import HTTPAdapter
from urllib3.util import Retry

from ingestion.models.confluence import ConfluenceDocument

ONE_MINUTE = 60
CAH_CONFLUENCE_HOST = "https://confluence.cardinalhealth.net"


def make_document_blob_name(page_title: str, prefix: str, suffix: str = ".html") -> str:
    """Helper function to create a GCS blob object name for a Confluence document.

    :param page_title: Title of the page.
    :type page_title: str
    :param prefix: Value prepended to the blob name, equivalent to a directory path.
    :type prefix: str
    :param suffix: Suffx to be used for the blob, defaults to ".html"
    :type suffix: str, optional
    :return: A GCS blob name.
    :rtype: str
    """
    return prefix + "/" + (quote(page_title, safe="") + suffix)


def get_confluence_document(page: Dict[str, Any], prefix: str) -> ConfluenceDocument:
    ancestor_docs = []
    ancestors = page.get("ancestors")
    if ancestors is not None:
        ancestor_docs = [
            get_confluence_document(page=a, prefix=prefix) for a in ancestors
        ]
    page_title = str(page.get("title", None))
    link = None
    path = page.get("_links", {}).get("webui", None)
    if path is not None:
        link = CAH_CONFLUENCE_HOST + path

    return ConfluenceDocument(
        source_id=str(page.get("id")),
        name=page_title,
        path=make_document_blob_name(
            page_title=page_title, prefix=prefix, suffix=".html"
        ),
        connector_type="confluence-connector",
        last_updated=page.get("version", {}).get("when", datetime.now()),
        content_type="text/plain",
        link=link,
        version_number=page.get("version", {}).get("number", None),
        type=page.get("type"),
        state=page.get("status"),
        status=page.get("status"),
        space=page.get("space"),
        ancestors=ancestor_docs,
        _links=page.get("_links"),
        body=page.get("body"),
    )


class ConfluenceServerAPI:
    """Class used to interact with the Confluence Server API."""

    def __init__(
        self, host: str = CAH_CONFLUENCE_HOST, access_token: str = None
    ) -> None:
        """Initialization of the API object.

        :param host: Host of the API to interact with.
        :type host: str
        """
        self.host = host
        self.headers = {}
        if access_token is not None:
            self.headers["Authorization"] = f"Bearer {access_token}"
        self.session = self._make_session()

    def _make_session(self) -> Session:
        """HTTP Session factory.

        :return: Session used to make HTTP requests within.
        :rtype: Session
        """
        session = Session()
        retries = Retry(
            total=3,
            backoff_factor=0.1,
            status_forcelist=[502, 503, 504],
            allowed_methods={"GET"},
        )
        session.mount("https://", HTTPAdapter(max_retries=retries))
        return session

    @sleep_and_retry
    @limits(calls=100, period=ONE_MINUTE)
    def get(self, uri: str, **request_kwargs) -> Response:
        """Wrapper function around session.get that ratelimits requests.

        :param uri: URI to GET.
        :type uri: str
        :return: Response of the GET request.
        :rtype: Response
        """
        url = self.host + uri
        if len(self.headers) > 0:
            if "headers" not in request_kwargs:
                request_kwargs["headers"] = self.headers
            else:
                if "Authorization" not in request_kwargs["headers"]:
                    request_kwargs["headers"]["Authorization"] = self.headers.get(
                        "Authorization"
                    )
        return self.session.get(url=url, **request_kwargs)


def get_all_confluence_space_pages(
    site_key: str,
    api: ConfluenceServerAPI,
    prefix: str,
    expand: List[str] = [],
    limit: int = None,
) -> List[ConfluenceDocument]:
    """Index all the pages in a Confluence space.

    :param space: Identifier of the space on Confluence.
    :type space: str
    :param api: ConfluenceServerAPI object to utilize to interact with the API.
    :type api: ConfluenceServerAPI
    :param limit: Debugging param, limits requests made while indexing, defaults to None
    :type limit: int, optional
    :return: List of ConfluenceDocument objects.
    :rtype: List[ConfluenceDocument]
    """
    uri = f"/rest/api/space/{site_key}/content/page?expand={','.join(expand)}"
    pages = []
    while True:
        response = api.get(uri)
        page_data = response.json()
        pages_info = page_data.get("results", [])
        uri = page_data.get("_links", {}).get("next", None)
        if len(pages_info) > 0:
            new_pages = [get_confluence_document(p, prefix=prefix) for p in pages_info]
            pages.extend(new_pages)
        if len(pages_info) == 0 or uri is None:
            break
        if isinstance(limit, int):
            if len(pages) >= limit:
                return pages[:limit]
    return pages


def include_page(
    page: ConfluenceDocument,
    ignore_paths: List[str],
    link_type: str = "webui",
    allowed_status: List[str] = ["current"],
) -> bool:
    """Helper function to determine whether a page should be included in a corpus.

    :param page: The page to check for inclusion in the corpus.
    :type page: ConfluenceDocument
    :param ignore_paths: The paths of documents possibly related to the page. If a path is found in the pages ancestors, returns True.
    :type ignore_paths: List[str]
    :param link_type: Type of link to evaluate for inclusion, defaults to "webui"
    :type link_type: str, optional
    :param allowed_status: Page status values to allow, defaults to ["current"]
    :type allowed_status: List[str], optional
    :return: Boolean reflecting whether the page should be allowed into the corpus.
    :rtype: bool
    """
    # page isn't a page we're ignoring
    if page.links.get(link_type) in ignore_paths:
        return False
    # Page has no ancestors we're ignoring
    ancestor_links = [a.links.get(link_type, None) for a in page.ancestors]
    if any([link in ignore_paths for link in ancestor_links]):
        return False
    # Page must have an allowed status
    if page.status not in allowed_status:
        return False
    return True


def get_page_attachments(
    page_id: str, api: ConfluenceServerAPI, prefix: str
) -> Dict[str, List[ConfluenceDocument]]:
    """Get attachments associated with a Confluence page.

    :param page_id: ID of the page to get attachments for.
    :type page_id: str
    :param api: ConfluenceServerAPI object to use.
    :type api: ConfluenceServerAPI
    :return: Dict of attachments related to the given confluence page.
    Key is given page ID, value is attachments.
    :rtype: Dict[str, List[ConfluenceDocument]]
    """
    uri = f"/rest/api/content/{page_id}/child/attachment"
    attachments = []
    while True:
        response = api.get(uri)
        page_info = response.json()
        new_attachments = page_info.get("results", [])
        uri = page_info.get("_links", {}).get("next", None)
        if len(new_attachments) > 0:
            attachments.extend(
                [
                    get_confluence_document(page=a, prefix=prefix)
                    for a in new_attachments
                ]
            )

        if len(new_attachments) == 0 or uri is None:
            break
    return {page_id: attachments}


def get_all_page_attachments(
    page_ids: List[str], api: ConfluenceServerAPI
) -> Dict[str, List[ConfluenceDocument]]:
    attachments = {}
    for attachment_dict in Parallel(n_jobs=4, return_as="generator", prefer="threads")(
        delayed(get_page_attachments)(pid, api) for pid in page_ids
    ):
        attachments.update(attachment_dict)
    return attachments


def format_documents_for_writing(documents: List[ConfluenceDocument]) -> str:
    write_str = ""
    for d in documents:
        write_str = write_str + d.model_dump_json(by_alias=True) + "\n"
    return write_str.rsplit("\n", 1)[0]
