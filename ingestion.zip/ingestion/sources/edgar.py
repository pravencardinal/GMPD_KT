import logging
import time
from pathlib import Path
from typing import List
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from zipfile import ZipFile

import pandera as pa
import requests
from google.cloud.storage import Bucket, Client
from joblib import Parallel, delayed
from pandas import DataFrame, read_csv
from ratelimit import limits, sleep_and_retry

from ingestion.models.edgar import EdgarFile

URI = "http://www.sec.gov/Archives/"
USER_AGENT = "aravind.sankaran@cardinalhealth.com"


@sleep_and_retry
@limits(calls=10, period=1)
def download_full_index_master(
    year: int,
    quarter: int,
    directory: Path,
    read_size: int = 1024,
    overwrite: bool = False,
) -> Path:
    "Download an EDGAR full-index file for a given year and quarter. Returns a file Path."
    logging.info(
        f"downloading fill-index file for year = {year} and quarter = {quarter}"
    )
    if not directory.exists():
        directory.mkdir()
    file_path = directory / f"{year}-QTR{quarter}-master.zip"
    if not file_path.exists() or overwrite:
        get_request = Request(
            url=URI + f"edgar/full-index/{year}/QTR{quarter}/master.zip",
            headers={"User-Agent": USER_AGENT},
        )
        with urlopen(get_request) as f_in:
            with file_path.open("wb+") as f_out:
                while True:
                    chunk = f_in.read(read_size)
                    if len(chunk) == 0:
                        break
                    f_out.write(chunk)
    return file_path


class MasterIndexSchema(pa.DataFrameModel):
    # CIK|Company Name|Form Type|Date Filed|Filename
    CIK: str = pa.Field()
    Company_Name: str = pa.Field(alias="Company Name")
    Form_Type: str = pa.Field(alias="Form Type")
    Date_Filed: str = pa.Field(alias="Date Filed")
    Filename: str = pa.Field()


def read_master_index(path: Path) -> DataFrame:
    master = (
        read_csv(ZipFile(path).open("master.idx"), header=5, sep="|", dtype=str)
        .iloc[1:, :]
        .reset_index(drop=True)
    )
    MasterIndexSchema.validate(master)
    return master


# def get_edgar_file_download_path(edgar_file_path: str, directory: Path) -> Path:
#     CIK, name = edgar_file_path.rsplit("/", 3)[-2:]
#     CIK_path = directory / CIK
#     return CIK_path / name


@sleep_and_retry
@limits(calls=10, period=1)
def get_edgar_file(
    edgar_file: EdgarFile,
    prefix: str,
    project_id: str,
    bucket_name: str,
    overwrite: bool = False,
    read_size: int = 1024,
    logger: logging.Logger = None,
) -> EdgarFile:
    "Download file from EDGAR, upload to GCS"
    if logger is None:
        logger = logging
    "Given an edgar file path, download and return local downloaded file path."
    gcs_path = edgar_file.get_gcs_path(prefix)
    logger.info(f"Downloading edgar file - {edgar_file.get_edgar_path()} to {gcs_path}")
    bucket = Client(project=project_id).get_bucket(bucket_name)
    get_request = Request(
        url=URI + edgar_file.get_edgar_path(), headers={"User-Agent": USER_AGENT}
    )
    while True:
        try:
            with urlopen(get_request) as f_in:
                with bucket.blob(gcs_path).open("wb") as f_out:
                    while True:
                        chunk = f_in.read(read_size)
                        if len(chunk) == 0:
                            break
                        else:
                            f_out.write(chunk)
            break
        except HTTPError as e:
            logger.error(e)
            if e.code == 301:
                logger.error(f"Skipping {edgar_file.get_edgar_path()} due to 301 Error")
                return None
            time.sleep(1)
    return EdgarFile


def get_edgar_files(
    edgar_files: List[EdgarFile],
    prefix: str,
    bucket: Bucket,
    overwrite: bool = False,
    logger: logging.Logger = None,
    workers: int = 5,
) -> List[EdgarFile]:
    """Get files from EDGAR, write to GCS."""
    if logger is None:
        logger = logging
    # Get downloaded files
    downloaded_files = [blob.name for blob in list(bucket.list_blobs(prefix=prefix))]
    # Filter list for paths not already downloaded
    edgar_files_to_get = [
        p for p in edgar_files if p.get_gcs_path(prefix) not in downloaded_files
    ]
    if len(edgar_files_to_get) == 0:
        return downloaded_files
    logger.info(f"Downloading {len(edgar_files_to_get)} EDGAR files")
    runner = Parallel(n_jobs=workers, prefer="threads")
    generator = runner(
        delayed(get_edgar_file)(
            edgar_file, prefix, bucket.user_project, bucket.name, overwrite
        )
        for edgar_file in edgar_files_to_get
    )
    downloaded_files.extend(list(generator))
    downloaded_files = [f for f in downloaded_files if f is not None]
    return downloaded_files


@sleep_and_retry
@limits(calls=10, period=1)
def get_cik_submissions(cik: str) -> dict:
    # https://data.sec.gov/submissions/CIK##########.json
    if not len(cik) == 10:
        raise ValueError("cik value must be 10 characters.")
    response = requests.get(
        f"https://data.sec.gov/submissions/CIK{cik}.json",
        headers={"User-Agent": "jake.bergren@cardinalhealth.com"},
    )
    return response.json()
