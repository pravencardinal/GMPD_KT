import asyncio
import itertools
from logging import Logger
from typing import Union

import requests
from azure.core.credentials import AccessToken
from azure.identity import UsernamePasswordCredential
from bs4 import BeautifulSoup
from google.cloud.storage import Blob, Bucket
from google.cloud.storage import Client as StorageClient
from msgraph import GraphServiceClient
from msgraph.generated.models.drive_item import DriveItem
from msgraph.generated.models.site import Site
from msgraph.generated.models.site_page import SitePage
from msgraph.generated.models.text_web_part import TextWebPart
from msgraph.generated.models.web_part import WebPart
from msgraph.generated.sites.item.pages.graph_site_page.graph_site_page_request_builder import (
    GraphSitePageRequestBuilder,
)
from msgraph.generated.sites.sites_request_builder import SitesRequestBuilder
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from ingestion.models.microsoft.sharepoint import (
    SharepointDrive,
    SharepointDriveFile,
    SharepointFile,
    SharepointFolder,
    SharepointPage,
    SharepointSiteIndex,
)


def get_sharepoint_site_id(
    site_title: str,
    credentials: UsernamePasswordCredential,
    client: GraphServiceClient,
    sites_or_teams: str,
    scope: str = "https://graph.microsoft.com/.default",
    host: str = "cardinalhealth.sharepoint.com",
) -> str:
    token: AccessToken = credentials.get_token(scope)
    base_url = client.path_parameters.get(
        "base_url", client.path_parameters.get("baseurl", None)
    )
    site_id_response = requests.get(
        f"{base_url}/sites/{host}:/{sites_or_teams}/{site_title}",
        headers={"Authorization": token.token},
    )
    site_id_response_json: dict = site_id_response.json()
    return site_id_response_json.get("id")


async def get_site(
    site_id: str, client: GraphServiceClient, get_root: bool = True
) -> Site:
    site = await client.sites.by_site_id(site_id=site_id).get(
        request_configuration=SitesRequestBuilder.SitesRequestBuilderGetRequestConfiguration(
            query_parameters=SitesRequestBuilder.SitesRequestBuilderGetQueryParameters(
                expand=[
                    "drives",
                ],
            )
        )
    )
    if site is not None:
        if get_root:
            for drive in site.drives:
                drive.root = await client.drives.by_drive_id(drive.id).root.get()
    return site


def convert_drive_item_to_sharepoint_model(
    drive_item: DriveItem,
) -> Union[SharepointFolder, SharepointFile]:
    if drive_item.file is None:
        return SharepointFolder(id=drive_item.id, name=drive_item.name)
    else:
        return SharepointFile(
            source_id=drive_item.id,
            name=drive_item.name,
            last_updated=drive_item.last_modified_date_time,
            size=drive_item.size,
            content_type=drive_item.file.mime_type,
            connector_type="sharepoint-connector",
            path="",
            link=drive_item.web_url,
            duration=drive_item.video.duration if drive_item.video else None,
        )


async def index_drive_folder(
    client: GraphServiceClient,
    drive_id: str,
    folder: SharepointFolder,
    path: str,
) -> list[(SharepointFolder, str)]:
    @retry(wait=wait_exponential(multiplier=1, min=4, max=10))
    async def get_folder_children(
        client: GraphServiceClient, drive_id: str, folder: SharepointFolder
    ):
        folder_children_response = (
            await client.drives.by_drive_id(drive_id)
            .items.by_drive_item_id(folder.id)
            .children.get()
        )
        return folder_children_response

    folders_to_search = []
    folder_children_response = await get_folder_children(
        client=client, drive_id=drive_id, folder=folder
    )
    if folder_children_response is not None:
        if folder_children_response.value is not None:
            for child in folder_children_response.value:
                child_model = convert_drive_item_to_sharepoint_model(child)
                if isinstance(child_model, SharepointFolder):
                    folders_to_search.append(
                        (child_model, f"{path}{child_model.name}/")
                    )
                folder.children[child_model.name] = child_model
    return folders_to_search


@retry(
    stop=stop_after_attempt(5),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    retry=retry_if_exception_type(Exception),
)
async def index_drive(
    drive: SharepointDrive,
    client: GraphServiceClient,
    drive_folders: list[str],
    skip_folders: list[str],
) -> None:
    drive.root = convert_drive_item_to_sharepoint_model(
        await client.drives.by_drive_id(drive.id).root.get()
    )
    # Get root children to initialize the search
    folders_to_search = [(drive.root, "/")]
    while len(folders_to_search) > 0:
        tasks = [
            index_drive_folder(
                client=client,
                drive_id=drive.id,
                folder=folder,
                path=path,
            )
            for folder, path in folders_to_search
            if any(path.startswith(d) or d.startswith(path) for d in drive_folders)
            and not any(path.startswith(s) for s in skip_folders)
        ]
        folders_to_search = list(
            itertools.chain.from_iterable(await asyncio.gather(*tasks))
        )


async def index_site_pages(
    site_id: str, client: GraphServiceClient, path_prefix: str
) -> list[SharepointPage]:
    @retry(wait=wait_exponential(multiplier=1, min=4, max=10))
    async def get_pages_with_link(link: str, client: GraphServiceClient):
        return await client.sites.with_url(link).get()

    pages_response = await client.sites.by_site_id(site_id).pages.get()
    if pages_response is not None:
        if pages_response.value is not None:
            pages = [
                SharepointPage(
                    source_id=p.id,
                    # some-page-name.aspx -> some-page-name.html since we are parsing out to an html file
                    name=p.name.rsplit(".", 1)[0] + ".html",
                    path="/".join([path_prefix, p.name.rsplit(".", 1)[0] + ".html"]),
                    connector_type="sharepoint-connector",
                    last_updated=p.last_modified_date_time,
                    content_type="text/html",
                    link=p.web_url,
                    parent=p.parent_reference.id,
                )
                for p in pages_response.value
            ]
    if pages_response.odata_next_link is not None:
        while pages_response.odata_next_link is not None:
            pages_response = await get_pages_with_link(
                link=pages_response.odata_next_link, client=client
            )
            if pages_response is not None:
                if pages_response.value is not None:
                    pages.extend(
                        [
                            SharepointPage(
                                source_id=p.id,
                                name=p.name,
                                last_updated=p.last_modified_date_time,
                                parent=p.parent_reference.id,
                                connector_type="sharepoint-connector",
                                path="",
                                link=p.web_url,
                            )
                            for p in pages_response.value
                        ]
                    )
    return pages


async def index_sharepoint_site(
    site_id: str,
    client: GraphServiceClient,
    site_pages_blob_path_prefix: str,
    drives: bool = True,
    drive_folders: dict[str, list[str]] | None = None,
    skip_folders: dict[str, list[str]] | None = None,
    pages: bool = True,
) -> SharepointSiteIndex:
    "Recursively query a Sharepoint site for all its files."
    # Get all drives
    site = await get_site(site_id=site_id, client=client)
    site_index: SharepointSiteIndex = SharepointSiteIndex.from_site(site=site)
    if pages:
        print("Indexing pages...")
        site_index.pages = await index_site_pages(
            site_id=site_id, client=client, path_prefix=site_pages_blob_path_prefix
        )
    if drives:
        if len(site.drives) > 0:
            if drive_folders:
                drives_to_index = [
                    drive for drive in site_index.drives if drive.name in drive_folders
                ]
            else:
                drives_to_index = site_index.drives
            print("Indexing", len(drives_to_index), "drives...")
            for drive in drives_to_index:
                print("Indexing drive", drive.name, "...")
                drive_list = (
                    drive_folders.get(drive.name, ["/"]) if drive_folders else ["/"]
                )  # Defaults to all files
                skip_list = (
                    skip_folders.get(drive.name, []) if skip_folders else []
                )  # Defaults to no files
                await index_drive(
                    drive=drive,
                    client=client,
                    drive_folders=drive_list,
                    skip_folders=skip_list,
                )
    print("Done")
    return site_index


def count_drive_files(drive: SharepointDrive) -> int:
    def count_folder_files(folder: SharepointFolder) -> int:
        count = 1
        for item in folder.children.values():
            if isinstance(item, SharepointFolder):
                count += count_folder_files(item)
            else:
                count += 1
        return count

    return count_folder_files(drive.root)


def get_folder_file_paths(
    prefix: str, folder: SharepointFolder
) -> list[tuple[str, SharepointFile]]:
    items = []
    for item in folder.children.values():
        if isinstance(item, SharepointFolder):
            items.extend(get_folder_file_paths(prefix + "/" + item.name, folder=item))
        else:
            items.append((prefix, item))
    return items


def retrieve_site_files(
    index: SharepointSiteIndex,
    blob_prefix: str = "",
) -> list[SharepointDriveFile]:
    """Optionally the sharepoint site files

    Args:
        index: SharepointSiteIndex to modify.
        drive_folders: Dict of drive folder paths to include. If included,
            all sub folders will be included. Keys are drive names.

    Returns:
        The modified index."""
    site_drive_files = []
    for drive in index.drives:
        for prefix, item in get_folder_file_paths(prefix="", folder=drive.root):
            item.path = "/".join([blob_prefix, drive.name + prefix, item.name])
            site_drive_files.append(
                SharepointDriveFile(
                    drive_name=drive.name,
                    drive_id=drive.id,
                    prefix=prefix,
                    **item.model_dump(),
                )
            )
    return site_drive_files


async def write_sharepoint_file_to_gcs(
    file: SharepointDriveFile,
    bucket: Bucket,
    storage_client: StorageClient,
    graph_client: GraphServiceClient,
    logger: Logger,
    blob_prefix: str = "",
) -> None:
    logger.debug(f"Writing file: {file.name}")
    file.path = "/".join([blob_prefix, file.drive_name + file.prefix, file.name])
    file_blob = Blob(name=file.path, bucket=bucket)
    file_bytes = (
        await graph_client.drives.by_drive_id(file.drive_id)
        .items.by_drive_item_id(file.source_id)
        .content.get()
    )
    if file_bytes is None:
        logger.error(
            f"Drive file not found - Drive: {file.drive_name}, File: {file.source_id} - {file.name} not found"
        )
        return
    with file_blob.open("wb") as f:
        f.write(file_bytes)
    file_blob.metadata = file.model_dump()
    file_blob.content_type = file.content_type
    file_blob.patch(client=storage_client)
    logger.debug(f"Done writing file: {file.name}")


async def get_site_page_with_web_parts(
    site_id: str, page_id: str, client: GraphServiceClient, logger: Logger = None
) -> None | SitePage:
    query_parameters = (
        GraphSitePageRequestBuilder.GraphSitePageRequestBuilderGetQueryParameters(
            filter="id eq '{}'".format(page_id), expand=["webParts"]
        )
    )
    request_configuration = (
        GraphSitePageRequestBuilder.GraphSitePageRequestBuilderGetRequestConfiguration(
            query_parameters=query_parameters
        )
    )
    try:
        get_site_page_response = await client.sites.by_site_id(
            site_id=site_id
        ).pages.graph_site_page.get(request_configuration=request_configuration)
    except Exception as e:
        if isinstance(logger, Logger):
            logger.exception(
                "Error getting site - %s page - %s: %s", site_id, page_id, e
            )
        return
    if get_site_page_response is not None:
        if get_site_page_response.value is not None:
            assert isinstance(get_site_page_response.value, list)
            site_page = get_site_page_response.value[0]
            assert site_page is not None
            assert site_page.web_parts is not None
            return site_page


def get_html_from_web_parts(title: str, web_parts: list[WebPart]) -> str:
    soup = BeautifulSoup(f"<head><title>{title}</title></head><body></body>")
    soup_body = soup.find("body")
    for part in web_parts:
        if isinstance(part, TextWebPart):
            part_div = soup.new_tag("div")
            part_soup = BeautifulSoup(markup=part.inner_html, features="html.parser")
            part_div.append(part_soup)
            soup_body.append(part_div)
    return soup.prettify()


async def get_confluence_page_html(
    site_id: str, page_id: str, graph_client: GraphServiceClient, logger: Logger = None
) -> str | None:
    if isinstance(logger, Logger):
        logger.debug(
            "Getting web parts for site - {} page - {}".format(site_id, page_id)
        )
    page_with_web_parts = await get_site_page_with_web_parts(
        site_id=site_id, page_id=page_id, client=graph_client, logger=logger
    )
    if page_with_web_parts is not None:
        return get_html_from_web_parts(
            title=page_with_web_parts.title, web_parts=page_with_web_parts.web_parts
        )


async def write_sharepoint_page_to_gcs(
    site_id: str,
    page: SharepointPage,
    bucket: Bucket,
    storage_client: StorageClient,
    graph_client: GraphServiceClient,
    logger: Logger = None,
) -> None:
    if isinstance(logger, Logger):
        logger.info(
            "Writing site - {} page name - {} page id - {} to GCS".format(
                site_id, page.name, page.source_id
            )
        )
    page_html = await get_confluence_page_html(
        site_id=site_id,
        page_id=page.source_id,
        graph_client=graph_client,
        logger=logger,
    )
    if page_html is None:
        if isinstance(logger, Logger):
            logger.info(
                f"Page name - {page.name} id - {page.source_id} web parts not found"
            )
        return
    page_blob = Blob(name=page.path, bucket=bucket)
    with page_blob.open("w") as f:
        f.write(page_html)
    page_blob.metadata = page.model_dump()
    page_blob.content_type = page.content_type
    page_blob.patch(client=storage_client)
