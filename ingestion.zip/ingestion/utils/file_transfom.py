import asyncio
import os
import subprocess
import tempfile
import time
from logging import Logger
from typing import List

from google.cloud.storage import (
    Blob,
    Bucket,
)
from google.cloud.storage import (
    Client as StorageClient,
)
from google.genai import Client as GenAIClient
from google.genai import types

from ingestion.models.file_transform import StructuredTranscriptItem, Transcription
from ingestion.models.microsoft.sharepoint import SharepointDriveFile


async def transcribe_file(
    file: SharepointDriveFile,
    transformed_path: str,
    storage_client: StorageClient,
    genai_client: GenAIClient,
    bucket: Bucket,
    logger: Logger = None,
) -> None:
    if file.duration is None:
        logger.error(f"Could not determine length of file - {file.name}")
        return

    file_length = file.duration / 1000  # ms to sec
    blob = bucket.blob(blob_name=file.path)

    with tempfile.NamedTemporaryFile(delete=True) as temp_file:
        blob.download_to_file(temp_file)
        temp_file.flush()
        local_file_path = temp_file.name

        start_time_sec = 0
        chunk_length_sec = 600  # 10 minutes
        tasks = []

        while start_time_sec < file_length:
            chunk_duration = (
                file_length - start_time_sec
                if start_time_sec + chunk_length_sec > file_length - 300
                else chunk_length_sec
            )
            task = transcribe_chunk(
                local_file_path=local_file_path,
                start_time_sec=start_time_sec,
                chunk_duration=chunk_duration,
                genai_client=genai_client,
            )
            tasks.append(task)
            start_time_sec += chunk_duration

        logger.debug(f"Starting transcription for {file.name}")
        try:
            partial_transcripts = await asyncio.gather(*tasks)

            all_structured_items = [
                transcript_item
                for partial_transcript in partial_transcripts
                for transcript_item in partial_transcript
            ]

            final_transcript = Transcription(structured_transcript=all_structured_items)

            transcript_bytes = final_transcript.model_dump_json().encode("utf-8")
            blob_prefix = f"{transformed_path}/transcriptions{file.prefix}"
            file.content_type = "application/json"
            file.size = len(transcript_bytes)
            base_name, _ = os.path.splitext(file.name)
            file.name = f"{base_name} transcript.json"
            file.path = f"{blob_prefix}/{file.name}"

            file_blob = Blob(name=file.path, bucket=bucket)
            with file_blob.open("wb") as f:
                f.write(transcript_bytes)

            file_blob.metadata = file.model_dump()
            file_blob.content_type = file.content_type
            file_blob.patch(client=storage_client)
            logger.debug(f"Completed Transcription for {file.name}")

        except Exception as e:
            logger.error(f"Error during transcription for {file.name}")
            raise e


async def transcribe_chunk(
    local_file_path: str,
    start_time_sec: float,
    chunk_duration: float,
    genai_client: GenAIClient,
) -> List[StructuredTranscriptItem]:
    command = [
        "ffmpeg",
        "-nostdin",
        "-i",
        local_file_path,
        "-ss",
        str(start_time_sec),
        "-t",
        str(chunk_duration),
        "-vn",
        "-c:a",
        "aac",
        "-f",
        "adts",
        "-",
    ]
    result = await asyncio.to_thread(
        subprocess.run,
        command,
        capture_output=True,
        check=True,
    )
    audio_chunk_bytes = result.stdout
    contents = [
        types.Part.from_text(text=transcription_prompt(start_time_sec, chunk_duration)),
        types.Part.from_bytes(data=audio_chunk_bytes, mime_type="audio/aac"),
    ]

    try:
        response = await genai_client.aio.models.generate_content(
            model="gemini-2.5-flash",
            contents=contents,
            config=types.GenerateContentConfig(
                audio_timestamp=True,
                response_mime_type="application/json",
                response_schema=Transcription,
                temperature=0.5,
            ),
        )
        transcription = Transcription.model_validate_json(response.text)
    except Exception as e:
        raise ValueError(f"Error Transcribing Chunk: {e}")
    return transcription.structured_transcript


def transcription_prompt(start_time: int, chunk_duration: int):
    return f"""
You are a specialized AI assistant for audio transcription and diarization. Your task is to process an audio chunk and return a structured JSON object that strictly adheres to the provided schema.

**Primary Goal and Context:**
The output you generate is critical for a Retrieval-Augmented Generation (RAG) system. This system relies on the precision of your transcription and timestamps to locate exact moments in the audio. Inaccurate timestamps will degrade the system's ability to find facts and answer questions.

This is a chunk of a larger audio file that starts at the {start_time} second mark and is {chunk_duration} seconds long. All timestamps must be within the range of {time.strftime('%H:%M:%S', time.gmtime(start_time))} to {time.strftime('%H:%M:%S', time.gmtime(start_time + chunk_duration))}.

To ensure the highest accuracy, you must follow these rules:
1.  **TIMESTAMP FORMAT**: Timestamps MUST be a string in the exact "MM:SS" (Minutes:Seconds) format.
    - CORRECT: "01:23"
    - INCORRECT: "1:23", "01:23.123", "123s"
    - **DO NOT** include milliseconds, frames, or any other unit of time. The format must have two digits for hours, minutes, and seconds.
2.  **VERBATIM TRANSCRIPTION**: Transcribe the speech exactly as spoken. Include all words, including filler words ("um", "uh"), false starts, and repetitions. Do not correct grammar, clean up the text or remove any words. 
3.  **SPEAKER LABELS**: Use consistent speaker labels (e.g., 'Speaker 1', 'Speaker 2'). If a speaker's name is clearly mentioned, use their name for all subsequent segments from that speaker.
4.  **SEGMENTATION**: Create a new segment only when the speaker changes or after a distinct pause in speech (2-3 seconds of silence).

The JSON object must conform to the following schema:

{{
    "structured_transcript": [
        {{
            "speaker_label": "<e.g., 'Speaker 1'>",
            "timestamp": "<:MM:SS>",
            "text": "<...>"
        }},
        {{
            "speaker_label": "<e.g., 'Speaker 2'>",
            "timestamp": "<:MM:SS>",
            "text": "<...>"
        }},
    ]
}}
"""
